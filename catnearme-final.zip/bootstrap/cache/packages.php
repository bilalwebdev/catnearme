<?php return array (
  'artesaos/seotools' => 
  array (
    'providers' => 
    array (
      0 => 'Artesaos\\SEOTools\\Providers\\SEOToolsServiceProvider',
    ),
    'aliases' => 
    array (
      'SEOMeta' => 'Artesaos\\SEOTools\\Facades\\SEOMeta',
      'OpenGraph' => 'Artesaos\\SEOTools\\Facades\\OpenGraph',
      'Twitter' => 'Artesaos\\SEOTools\\Facades\\TwitterCard',
      'JsonLd' => 'Artesaos\\SEOTools\\Facades\\JsonLd',
      'SEO' => 'Artesaos\\SEOTools\\Facades\\SEOTools',
    ),
  ),
  'coliving/commentable' => 
  array (
    'providers' => 
    array (
      0 => 'Artisanry\\Commentable\\CommentableServiceProvider',
    ),
  ),
  'digikraaft/laravel-review-rating' => 
  array (
    'providers' => 
    array (
      0 => 'Digikraaft\\ReviewRating\\ReviewRatingServiceProvider',
    ),
  ),
  'diglactic/laravel-breadcrumbs' => 
  array (
    'providers' => 
    array (
      0 => 'Diglactic\\Breadcrumbs\\ServiceProvider',
    ),
    'aliases' => 
    array (
      'Breadcrumbs' => 'Diglactic\\Breadcrumbs\\Breadcrumbs',
    ),
  ),
  'ebess/advanced-nova-media-library' => 
  array (
    'providers' => 
    array (
      0 => 'Ebess\\AdvancedNovaMediaLibrary\\AdvancedNovaMediaLibraryServiceProvider',
    ),
  ),
  'inertiajs/inertia-laravel' => 
  array (
    'providers' => 
    array (
      0 => 'Inertia\\ServiceProvider',
    ),
  ),
  'intervention/image' => 
  array (
    'providers' => 
    array (
      0 => 'Intervention\\Image\\ImageServiceProvider',
    ),
    'aliases' => 
    array (
      'Image' => 'Intervention\\Image\\Facades\\Image',
    ),
  ),
  'kalnoy/nestedset' => 
  array (
    'providers' => 
    array (
      0 => 'Kalnoy\\Nestedset\\NestedSetServiceProvider',
    ),
  ),
  'laravel/cashier' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Cashier\\CashierServiceProvider',
    ),
  ),
  'laravel/cashier-paddle' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Paddle\\CashierServiceProvider',
    ),
  ),
  'laravel/legacy-factories' => 
  array (
    'providers' => 
    array (
      0 => 'Illuminate\\Database\\Eloquent\\LegacyFactoryServiceProvider',
    ),
  ),
  'laravel/nova' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Nova\\NovaCoreServiceProvider',
    ),
    'aliases' => 
    array (
      'Nova' => 'Laravel\\Nova\\Nova',
    ),
  ),
  'laravel/sail' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Sail\\SailServiceProvider',
    ),
  ),
  'laravel/sanctum' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Sanctum\\SanctumServiceProvider',
    ),
  ),
  'laravel/tinker' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Tinker\\TinkerServiceProvider',
    ),
  ),
  'laravel/ui' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Ui\\UiServiceProvider',
    ),
  ),
  'livewire/livewire' => 
  array (
    'providers' => 
    array (
      0 => 'Livewire\\LivewireServiceProvider',
    ),
    'aliases' => 
    array (
      'Livewire' => 'Livewire\\Livewire',
    ),
  ),
  'mostafaznv/larupload' => 
  array (
    'providers' => 
    array (
      0 => 'Mostafaznv\\Larupload\\LaruploadServiceProvider',
    ),
  ),
  'mostafaznv/nova-video' => 
  array (
    'providers' => 
    array (
      0 => 'Mostafaznv\\NovaVideo\\VideoFieldServiceProvider',
    ),
  ),
  'musonza/chat' => 
  array (
    'providers' => 
    array (
      0 => 'Musonza\\Chat\\ChatServiceProvider',
    ),
    'aliases' => 
    array (
      'Chat' => 'Musonza\\Chat\\Facades\\ChatFacade',
    ),
  ),
  'nesbot/carbon' => 
  array (
    'providers' => 
    array (
      0 => 'Carbon\\Laravel\\ServiceProvider',
    ),
  ),
  'nova-kit/nova-packages-tool' => 
  array (
    'providers' => 
    array (
      0 => 'NovaKit\\NovaPackagesTool\\LaravelServiceProvider',
    ),
  ),
  'novius/laravel-nova-order-nestedset-field' => 
  array (
    'providers' => 
    array (
      0 => 'Novius\\LaravelNovaOrderNestedsetField\\OrderNestedsetFieldServiceProvider',
    ),
  ),
  'nunomaduro/collision' => 
  array (
    'providers' => 
    array (
      0 => 'NunoMaduro\\Collision\\Adapters\\Laravel\\CollisionServiceProvider',
    ),
  ),
  'nunomaduro/termwind' => 
  array (
    'providers' => 
    array (
      0 => 'Termwind\\Laravel\\TermwindServiceProvider',
    ),
  ),
  'ralphjsmit/laravel-helpers' => 
  array (
    'providers' => 
    array (
      0 => 'RalphJSmit\\Helpers\\HelpersServiceProvider',
    ),
    'aliases' => 
    array (
      'Helpers' => 'RalphJSmit\\Helpers\\Facades\\Helpers',
    ),
  ),
  'ralphjsmit/laravel-seo' => 
  array (
    'providers' => 
    array (
      0 => 'RalphJSmit\\Laravel\\SEO\\LaravelSEOServiceProvider',
    ),
    'aliases' => 
    array (
      'SEOManager' => 'RalphJSmit\\Laravel\\SEO\\Facades\\SEOManager',
    ),
  ),
  'rap2hpoutre/fast-excel' => 
  array (
    'providers' => 
    array (
      0 => 'Rap2hpoutre\\FastExcel\\Providers\\FastExcelServiceProvider',
    ),
  ),
  'spatie/eloquent-sortable' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\EloquentSortable\\EloquentSortableServiceProvider',
    ),
  ),
  'spatie/laravel-fractal' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\Fractal\\FractalServiceProvider',
    ),
    'aliases' => 
    array (
      'Fractal' => 'Spatie\\Fractal\\Facades\\Fractal',
    ),
  ),
  'spatie/laravel-ignition' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\LaravelIgnition\\IgnitionServiceProvider',
    ),
    'aliases' => 
    array (
      'Flare' => 'Spatie\\LaravelIgnition\\Facades\\Flare',
    ),
  ),
  'spatie/laravel-medialibrary' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\MediaLibrary\\MediaLibraryServiceProvider',
    ),
  ),
  'spatie/laravel-sitemap' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\Sitemap\\SitemapServiceProvider',
    ),
  ),
  'spatie/laravel-tags' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\Tags\\TagsServiceProvider',
    ),
  ),
  'spatie/laravel-translatable' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\Translatable\\TranslatableServiceProvider',
    ),
  ),
  'spatie/nova-tags-field' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\TagsField\\TagsFieldServiceProvider',
    ),
  ),
  'superlatif/nova-tag-input' => 
  array (
    'providers' => 
    array (
      0 => 'Superlatif\\NovaTagInput\\FieldServiceProvider',
    ),
  ),
);