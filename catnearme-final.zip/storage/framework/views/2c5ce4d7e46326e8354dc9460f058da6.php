<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['title' => null, 'selectTitle' => 'Select Of Country' , 'model' => $attributes->whereStartsWith('wire:model')->first() , 'options' => null, 'value' => null, 'track_by' => 'id' , 'track_display' => 'name', 'field' => null]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['title' => null, 'selectTitle' => 'Select Of Country' , 'model' => $attributes->whereStartsWith('wire:model')->first() , 'options' => null, 'value' => null, 'track_by' => 'id' , 'track_display' => 'name', 'field' => null]); ?>
<?php foreach (array_filter((['title' => null, 'selectTitle' => 'Select Of Country' , 'model' => $attributes->whereStartsWith('wire:model')->first() , 'options' => null, 'value' => null, 'track_by' => 'id' , 'track_display' => 'name', 'field' => null]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div class="input-box">
    <?php if($title): ?>
        <label class="label-text"><?php echo e($title); ?></label>
    <?php endif; ?>
    <div class="form-group user-chosen-select-container" wire:ignore>
        <select class="user-chosen-select country" id="<?php echo e(is_null($field) ? $model : $model . '_' . $field); ?>">
            <option value=""><?php echo e($selectTitle); ?></option>
            <?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($option[$track_by]); ?>" <?php echo e($option[$track_by] == $value ? 'selected' : ''); ?>><?php echo e($option[$track_display]); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div><!-- end form-group -->

    <?php $__env->startPush('scripts'); ?>
        <script>
            <?php if(is_null($field)): ?>
                $('#<?php echo e($model); ?>').chosen().change(function (e) {
                    window.livewire.find('<?php echo e($_instance->id); ?>').set('<?php echo e($model); ?>', e.target.value)
                })
            <?php else: ?>
                $('#<?php echo e($model); ?>_<?php echo e($field); ?>').chosen().change(function (e) {
                    window.livewire.find('<?php echo e($_instance->id); ?>').set('<?php echo e($model); ?>.<?php echo e($field); ?>', e.target.value)
                })
            <?php endif; ?>
        </script>
    <?php $__env->stopPush(); ?>
</div>
<?php /**PATH D:\personal\catnearme\resources\views/components/home/ui/country.blade.php ENDPATH**/ ?>