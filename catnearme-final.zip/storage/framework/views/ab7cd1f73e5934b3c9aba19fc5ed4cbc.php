<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['title',  'model' => $attributes->whereStartsWith('wire:model')->first() , 'icon' => null ]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['title',  'model' => $attributes->whereStartsWith('wire:model')->first() , 'icon' => null ]); ?>
<?php foreach (array_filter((['title',  'model' => $attributes->whereStartsWith('wire:model')->first() , 'icon' => null ]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div class="form-group mb-0">

    <?php if(! is_null($icon)): ?>
        <span class="<?php echo e($icon); ?> form-icon"></span>
    <?php endif; ?>

    <input class="form-control  <?php $__errorArgs = [$model];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> form-control-error is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="search" placeholder="<?php echo e(__('Search By Keyword')); ?>" wire:model.defer="<?php echo e($model); ?>">

    <?php $__errorArgs = [$model];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      <p class="font-size-14 mt-n2 text-color-15"><?php echo e($message); ?></p>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<?php /**PATH D:\personal\catnearme\resources\views/components/home/ui/input.blade.php ENDPATH**/ ?>