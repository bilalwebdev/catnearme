<header class="header-area position-inherit top-auto bg-white" wire:ignore.self>
    <div class="header-top-bar bg-dark py-2 padding-right-30px padding-left-30px">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-6 d-flex align-items-center header-top-info font-size-14 font-weight-medium">
                    <p class="login-and-signup-wrap">
                        <?php if(auth()->guard()->check()): ?>
                            <a href="<?php echo e(route('dashboard')); ?>">
                                <span class="mr-1 la la-sign-in"></span><?php echo e(__('My dashboard')); ?>

                            </a>
                        <?php elseif(auth()->guard()->guest()): ?>
                            <a href="#" data-toggle="modal" data-target="#loginModal">
                                <span class="mr-1 la la-sign-in"></span><?php echo e(__('Login')); ?>

                            </a>
                            <span class="or-text px-2"><?php echo e(__('or')); ?></span>
                            <a href="#" data-toggle="modal" data-target="#signUpModal">
                                <span class="mr-1 la la-user-plus"></span><?php echo e(__('Sign Up')); ?>

                            </a>
                        <?php endif; ?>
                    </p>
                </div><!-- end col-lg-6 -->
                <div class="col-lg-6 d-flex align-items-center justify-content-end header-top-info">
                    <span class="mr-2 text-white font-weight-semi-bold font-size-14"><?php echo e(__('Follow CatNearMe on')); ?>:</span>
                    <ul class="social-profile social-profile-colored">
                        <li><a href="<?php echo e(config('cat.social.facebook')); ?>" class="facebook-bg"><i class="lab la-facebook-f"></i></a></li>
                        <li><a href="<?php echo e(config('cat.social.youtube')); ?>" class="twitter-bg"><i class="lab la-youtube"></i></a></li>
                        <li><a href="<?php echo e(config('cat.social.instagram')); ?>" class="instagram-bg"><i class="lab la-instagram"></i></a></li>
                    </ul>
                </div>
            </div><!-- end row -->
        </div><!-- end container-fluid -->
    </div><!-- end header-top-bar -->
    <div class="header-menu-wrapper padding-right-30px padding-left-30px">
        <div class="container-fluid ">
            <div class="row">
                <div class="col-lg-12">
                    <div class="menu-full-width">
                        <div class="logo">
                            <a href="<?php echo e(route('home')); ?>" class="sticky-logo-hide">
                                <img src="<?php echo e(Vite::asset('resources/images/logo-black.png')); ?>" alt="logo" width="135"
                                     height="38">
                            </a>
                            <a href="<?php echo e(route('home')); ?>" class="sticky-logo-show">
                                <img src="<?php echo e(Vite::asset('resources/images/logo.png')); ?>" alt="logo" width="135"
                                     height="38">
                            </a>
                            <div class="d-flex align-items-center">
                                <a href="<?php echo e(route('pets.add')); ?>" class="btn-gray add-listing-btn-show font-size-24 mr-2 flex-shrink-0 text-color" data-toggle="tooltip" data-placement="left" title="Add Listing">
                                    <i class="la la-plus"></i>
                                </a>
                                <div class="menu-toggle menu-toggle-black">
                                    <span class="menu__bar"></span>
                                    <span class="menu__bar"></span>
                                    <span class="menu__bar"></span>
                                </div><!-- end menu-toggle -->
                            </div>
                        </div><!-- end logo -->
                        <div class="main-menu-content main-menu-content-2 border-left-color">
                            <?php echo $__env->make('__shared/home/header/nav2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div><!-- end main-menu-content -->
                        <div class="nav-right-content ml-auto">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('breeder')): ?>
                                <a href="<?php echo e(route('pets.add')); ?>" class="theme-btn gradient-btn shadow-none add-listing-btn-hide">
                                    <i class="la la-layer-group mr-2"></i><?php echo e(__('Add Pet')); ?>

                                </a>
                            <?php elseif (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('client')): ?>
                                <a href="<?php echo e(route('dashboard')); ?>" class="theme-btn gradient-btn shadow-none add-listing-btn-hide">
                                    <i class="la la-layer-group mr-2"></i><?php echo e(__('My dashboard')); ?>

                                </a>
                            <?php endif; ?>
                        </div><!-- end nav-right-content -->
                    </div><!-- end menu-full-width -->
                </div><!-- end col-lg-12 -->
            </div><!-- end row -->
        </div><!-- end container-fluid -->
    </div><!-- end header-menu-wrapper -->
</header>
<?php /**PATH D:\personal\catnearme\resources\views/livewire/home/headers/white.blade.php ENDPATH**/ ?>