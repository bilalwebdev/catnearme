<div>
    <!-- Modal -->
    <div class="modal fade modal-container new-password" id="new-password" tabindex="-1" role="dialog" aria-labelledby="newPasswordModalTitle" aria-hidden="true" wire:ignore.self>
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header align-items-center mh-bg">
                    <h5 class="modal-title" id="newPasswordModalTitle">New Password</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true" class="la la-times-circle"></span>
                    </button>
                </div>
                <div class="modal-body">
                    <p class="font-size-15 font-weight-medium pb-3">
                        Set a new password for your account
                    </p>
                    <div class="form-box">
                        <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.home.ui.input-box','data' => ['icon' => 'la la-user','title' => ''.e(__('Email')).'','placeholder' => ''.e(__('Email address')).'','wire:model.defer' => 'email','readonly' => true,'disabled' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('home.ui.input-box'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => 'la la-user','title' => ''.e(__('Email')).'','placeholder' => ''.e(__('Email address')).'','wire:model.defer' => 'email','readonly' => true,'disabled' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.home.ui.input-box-password','data' => ['icon' => 'la la-user','title' => ''.e(__('New Password')).'','placeholder' => ''.e(__('Set new password')).'','wire:model.defer' => 'password']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('home.ui.input-box-password'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => 'la la-user','title' => ''.e(__('New Password')).'','placeholder' => ''.e(__('Set new password')).'','wire:model.defer' => 'password']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                        <div class="btn-box">
                            <button type="submit" class="theme-btn gradient-btn w-100" wire:click="setNewPassword">
                                Update password <i class="la la-arrow-right ml-1"></i>
                            </button>
                            <p class="sub-text-box text-right pt-1 font-weight-medium font-size-14">
                                Not a member? <a class="text-color-2 signup-btn" href="javascript:void(0)">Create account</a>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\personal\catnearme\resources\views/livewire/account/new-password.blade.php ENDPATH**/ ?>