<nav class="main-menu">
    <ul>
        <li>
            <a href="<?php echo e(route('home')); ?>"><?php echo e(__('Home')); ?></a>
        </li>
        <li>
            <a href="<?php echo e(route('about')); ?>"><?php echo e(__('About Us')); ?></a>
        </li>
        <li>
            <a href="<?php echo e(route('listings')); ?>"><?php echo e(__('Listings')); ?></a>
        </li>
        <li>
            <a href="<?php echo e(route('page.breeds')); ?>"><?php echo e(__('All Breeds')); ?></a>
        </li>
        <li>
            <a href="<?php echo e(route('blog')); ?>"><?php echo e(__('Blog')); ?></a>
        </li>
        <li>
            <a href="<?php echo e(route('contacts')); ?>"><?php echo e(__('Contact Us')); ?></a>
        </li>
    </ul>
</nav>
<?php /**PATH D:\personal\catnearme\resources\views/__shared/home/header/nav.blade.php ENDPATH**/ ?>