<div>
    <!-- Modal -->
    <div class="modal fade modal-container recover-form" id="recoverModal" tabindex="-1" role="dialog" aria-labelledby="recoverModalTitle" aria-hidden="true" wire:ignore.self>
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header align-items-center mh-bg">
                    <h5 class="modal-title" id="recoverModalTitle">Reset password</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true" class="la la-times-circle"></span>
                    </button>
                </div>
                <div class="modal-body">
                    <p class="font-size-15 font-weight-medium pb-3">
                        Enter your email to reset your password.
                        You will receive an email with instructions on how to reset your password. If you are experiencing problems
                        resetting your password <a href="<?php echo e(route('contacts')); ?>" class="text-color-2">contact us</a> for help.
                    </p>
                    <div class="form-box">
                        <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.home.ui.input-box','data' => ['icon' => 'la la-user','title' => ''.e(__('Email')).'','placeholder' => ''.e(__('Email address')).'','wire:model.defer' => 'email']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('home.ui.input-box'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => 'la la-user','title' => ''.e(__('Email')).'','placeholder' => ''.e(__('Email address')).'','wire:model.defer' => 'email']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                        <div class="btn-box">
                            <button type="submit" class="theme-btn gradient-btn w-100" wire:click="sendReset">
                                Get New Password <i class="la la-arrow-right ml-1"></i>
                            </button>
                            <p class="sub-text-box text-right pt-1 font-weight-medium font-size-14">
                                Not a member? <a class="text-color-2 signup-btn" href="javascript:void(0)">Create account</a>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\personal\catnearme\resources\views/livewire/account/reset-password.blade.php ENDPATH**/ ?>