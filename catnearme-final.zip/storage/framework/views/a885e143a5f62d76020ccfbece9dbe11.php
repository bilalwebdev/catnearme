<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['title' => 'Region', 'selectTitle' => 'Select ...' , 'model' => $attributes->whereStartsWith('wire:model')->first() , 'options' => null, 'value' => null,  'trackBy' => 'id' , 'select' => 'title']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['title' => 'Region', 'selectTitle' => 'Select ...' , 'model' => $attributes->whereStartsWith('wire:model')->first() , 'options' => null, 'value' => null,  'trackBy' => 'id' , 'select' => 'title']); ?>
<?php foreach (array_filter((['title' => 'Region', 'selectTitle' => 'Select ...' , 'model' => $attributes->whereStartsWith('wire:model')->first() , 'options' => null, 'value' => null,  'trackBy' => 'id' , 'select' => 'title']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div>
    <label class="label-text"><?php echo e($title); ?></label>
    <select class="form-control-select w-100 <?php $__errorArgs = [$model];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> form-control-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" style="height: 40px; margin-bottom: 15px" id="<?php echo e($model); ?>" wire:model.defer="<?php echo e($model); ?>">
        <option><?php echo e($selectTitle); ?></option>
        <?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($option[$trackBy]); ?>"><?php echo e($option[$select]); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>

    <?php $__errorArgs = [$model];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <p class="font-size-14 mt-n2 text-color-15"><?php echo e($message); ?></p>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

</div>
<?php /**PATH D:\personal\catnearme\resources\views/components/home/ui/chosen.blade.php ENDPATH**/ ?>