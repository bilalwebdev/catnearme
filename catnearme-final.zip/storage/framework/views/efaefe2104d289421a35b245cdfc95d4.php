<!DOCTYPE html>
<html lang="en">
<head>
<style>
.main-menu ul li {

    padding-right: 15px !important;

}
@media (min-width: 1201px) and (max-width: 1250px) {
.theme-btn.gradient-btn.shadow-none.add-listing-btn-hide{
font-size:10px;
font-weight:400px 
}
}
</style>

    <meta http-equiv="content-type" content="text/html; charset=utf-8">
    <meta name="author" content="TechyDevs">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <?php echo SEOMeta::generate(); ?>


    <!-- Favicon -->
    <link rel="icon" href="<?php echo e(asset('images/fav.png')); ?>">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Be+Vietnam:wght@100;300;400;500;600;700;800&display=swap" rel="stylesheet">

    <?php echo app('Illuminate\Foundation\Vite')('resources/sass/style.scss'); ?>

    <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/toastify-js"></script>
    <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css">

    <!-- Load Leaflet from CDN -->
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.6.0/dist/leaflet.css"
          integrity="sha512-xwE/Az9zrjBIphAcBb3F6JVqxf46+CDLwfLMHloNu6KEQCAWi6HcDUbeOfBIptF7tcCzusKFjFw2yuvEpDL9wQ=="
          crossorigin=""/>
    <script src="https://unpkg.com/leaflet@1.6.0/dist/leaflet.js"
            integrity="sha512-gZwIG9x3wUXg2hdXF6+rVkLF/0Vi9U8D2Ntg4Ga5I5BZpVkVxlJWbSQtXPSiUTtC0TjtGOmxa1AJPuV0CPthew=="
            crossorigin=""></script>


    <!-- Load Esri Leaflet from CDN -->
    <script src="https://unpkg.com/esri-leaflet@2.4.1/dist/esri-leaflet.js"
            integrity="sha512-xY2smLIHKirD03vHKDJ2u4pqeHA7OQZZ27EjtqmuhDguxiUvdsOuXMwkg16PQrm9cgTmXtoxA6kwr8KBy3cdcw=="
            crossorigin=""></script>

    <!-- Load Esri Leaflet Geocoder from CDN -->
    <link rel="stylesheet" href="https://unpkg.com/esri-leaflet-geocoder@2.3.3/dist/esri-leaflet-geocoder.css"
          integrity="sha512-IM3Hs+feyi40yZhDH6kV8vQMg4Fh20s9OzInIIAc4nx7aMYMfo+IenRUekoYsHZqGkREUgx0VvlEsgm7nCDW9g=="
          crossorigin="">
    <script src="https://unpkg.com/esri-leaflet-geocoder@2.3.3/dist/esri-leaflet-geocoder.js"
            integrity="sha512-HrFUyCEtIpxZloTgEKKMq4RFYhxjJkCiF5sDxuAokklOeZ68U2NPfh4MFtyIVWlsKtVbK5GD2/JzFyAfvT5ejA=="
            crossorigin=""></script>

    <?php echo \Livewire\Livewire::styles(); ?>


    <?php echo $__env->yieldPushContent('styles'); ?>

</head>
<body>
<!-- start per-loader -->
<div class="loader-container">
    <div class="loader-ripple">
        <div></div>
        <div></div>
    </div>
</div>
<!-- end per-loader -->

<section class="dashboard-wrap d-flex">

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('breeder')): ?>
        <?php echo $__env->make('__shared.home.header.dashboard.breeder', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php elseif (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('client')): ?>
        <?php echo $__env->make('__shared.home.header.dashboard.client', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

    <div class="dashboard-body d-flex flex-column">
        <div class="dashboard-inner-body flex-grow-1">
            <nav class="navbar navbar-expand bg-navbar dashboard-topbar mb-4">
                <button id="sidebarToggleTop" class="btn rounded-circle mr-3">
                    <i class="la la-bars"></i>
                </button>
                <ul class="navbar-nav ml-auto">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('breeder')): ?>
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('dashboard.headers.alerts', [])->html();
} elseif ($_instance->childHasBeenRendered('su8x3y5')) {
    $componentId = $_instance->getRenderedChildComponentId('su8x3y5');
    $componentTag = $_instance->getRenderedChildComponentTagName('su8x3y5');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('su8x3y5');
} else {
    $response = \Livewire\Livewire::mount('dashboard.headers.alerts', []);
    $html = $response->html();
    $_instance->logRenderedChild('su8x3y5', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    <?php endif; ?>
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('dashboard.headers.messages', [])->html();
} elseif ($_instance->childHasBeenRendered('XlI3ROB')) {
    $componentId = $_instance->getRenderedChildComponentId('XlI3ROB');
    $componentTag = $_instance->getRenderedChildComponentTagName('XlI3ROB');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('XlI3ROB');
} else {
    $response = \Livewire\Livewire::mount('dashboard.headers.messages', []);
    $html = $response->html();
    $_instance->logRenderedChild('XlI3ROB', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    <li class="nav-item dropdown border-left pl-3 ml-4">
                        <a class="nav-link dropdown-toggle after-none" href="#" id="userDropdown" role="button"
                           data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <div class="user-thumb user-thumb-sm position-relative">
                                <img src="<?php echo e(auth()->user()->getFirstMediaUrl('avatar' , 'thumb')); ?>">
                                <div class="status-indicator bg-success"></div>
                            </div>
                            <span
                                class="ml-2 small font-weight-medium d-none d-lg-inline"><?php echo e(auth()->user()->username); ?></span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-sm dropdown-menu-right animated--grow-in py-2"
                             aria-labelledby="userDropdown">
                            <a class="dropdown-item text-color font-size-15" href="<?php echo e(route('dashboard.profile')); ?>">
                                <i class="la la-user mr-2 text-gray font-size-18"></i>
                                <?php echo e(__('Profile')); ?>

                            </a>
                            <a class="dropdown-item text-color font-size-15" href="<?php echo e(route('dashboard.chat')); ?>">
                                <i class="la la-envelope mr-2 text-gray font-size-18"></i>
                                <?php echo e(__('Messages')); ?>

                            </a>

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('breeder')): ?>
                                <a class="dropdown-item text-color font-size-15" href="<?php echo e(route('pets.add')); ?>">
                                    <i class="la la-plus-circle mr-2 text-gray font-size-18"></i>
                                    <?php echo e(__('Add Listing')); ?>

                                </a>
                            <?php elseif (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('client')): ?>
                                <a class="dropdown-item text-color font-size-15" href="<?php echo e(route('listings')); ?>">
                                    <i class="la la-arrow-right mr-2 text-gray font-size-18"></i>
                                    <?php echo e(__('Go listing')); ?>

                                </a>
                            <?php endif; ?>
                            <a class="dropdown-item text-color font-size-15" href="<?php echo e(route('logout')); ?>">
                                <i class="la la-power-off mr-2 text-gray font-size-18"></i>
                                <?php echo e(__('Logout')); ?>

                            </a>
                        </div>
                    </li>
                </ul>
            </nav><!-- end dashboard-topbar -->
            <?php echo $__env->yieldContent('content'); ?>
        </div><!-- end dashboard-inner-body -->
        <?php echo $__env->make('__shared.home.footer.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div><!-- end dashboard-body -->
</section>

<!-- Template JS Files -->
<script src="/assets/home/js/jquery-3.4.1.min.js"></script>
<script src="/assets/home/js/jquery-ui.js"></script>
<script src="/assets/home/js/popper.min.js"></script>
<script src="/assets/home/js/bootstrap.min.js"></script>
<script src="/assets/home/js/owl.carousel.min.js"></script>
<script src="/assets/home/js/jquery.fancybox.min.js"></script>
<script src="/assets/home/js/animated-headline.js"></script>
<script src="/assets/home/js/chosen.min.js"></script>
<script src="/assets/home/js/moment.min.js"></script>
<script src="/assets/home/js/datedropper.min.js"></script>
<script src="/assets/home/js/waypoints.min.js"></script>
<script src="/assets/home/js/jquery.counterup.min.js"></script>
<script src="<?php echo e(asset('assets\home\js\emojionearea.min.js')); ?>"></script>
<script src="/assets/home/js/main.js"></script>

<?php echo \Livewire\Livewire::scripts(); ?>


<?php echo $__env->yieldPushContent('scripts'); ?>

<script>

    window.addEventListener('toast-error', (e) => {
        Toastify({
            text: e.detail.message,
            className: "error",
            style: {
                background: "linear-gradient(270deg,#e85f90,#d56868)"
            },
            offset: {
                x: 50, // horizontal axis - can be a number or a string indicating unity. eg: '2em'
                y: 10 // vertical axis - can be a number or a string indicating unity. eg: '2em'
            },
            duration: 5000
        }).showToast();
    })

    window.addEventListener('toast-success', (e) => {
        Toastify({
            text: e.detail.message,
            className: "success",
            style: {
                background: "linear-gradient(270deg,#44eec3,#16d918)"
            },
            offset: {
                x: 50, // horizontal axis - can be a number or a string indicating unity. eg: '2em'
                y: 10 // vertical axis - can be a number or a string indicating unity. eg: '2em'
            },
            duration: 5000
        }).showToast();
    })

</script>


</body>
</html>
<?php /**PATH D:\personal\catnearme\resources\views/layouts/dashboard.blade.php ENDPATH**/ ?>