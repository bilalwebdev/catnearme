<ul class="list-items bread-list">
    <?php $__currentLoopData = $breadcrumbs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $breadcrumb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(!is_null($breadcrumb->url) && !$loop->last): ?>
            <li><a href="<?php echo e($breadcrumb->url); ?>"><?php echo e($breadcrumb->title); ?></a></li>
        <?php else: ?>
            <li><?php echo e($breadcrumb->title); ?></li>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php /**PATH D:\personal\catnearme\resources\views/partials/breadcrumbs-list.blade.php ENDPATH**/ ?>