<!-- ================================
           START BLOG AREA
    ================================= -->
<section class="blog-area section-padding">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="section-heading text-center">
                    <p class="sec__desc pb-2"><?php echo e(__('From Our Blog')); ?></p>
                    <h2 class="sec__title mb-0"><?php echo e(__('What\'s on Our Mind')); ?></h2>
                </div><!-- end section-heading -->
            </div><!-- end col-lg-12 -->
        </div><!-- end row -->
        <div class="row padding-top-60px">
            <?php $__empty_1 = true; $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col-lg-4 responsive-column">
                    <div class="card-item card-item-layout-2">
                        <div class="card-image">
                            <a href="<?php echo e(route('blog.detail', $blog)); ?>" class="d-block">
                                <img src="<?php echo e($blog->getFirstMediaUrl('image' , 'thumb')); ?>" data-src="<?php echo e($blog->getFirstMediaUrl('image' , 'thumb')); ?>" class="card__img lazy" alt="<?php echo e($blog->title); ?>">
                                <span class="badge"><?php echo e($blog->created_at->isoFormat('MMMM D YYYY')); ?></span>
                            </a>
                        </div><!-- end card-image -->
                        <div class="card-content">
                            <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.home.feature.tags','data' => ['href' => route('blog'),'tags' => $blog->tags]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('home.feature.tags'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('blog')),'tags' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($blog->tags)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>

                            <h4 class="card-title pt-2 font-size-22">
                                <a href="<?php echo e(route('blog.detail', $blog)); ?>"><?php echo e($blog->title); ?></a>
                            </h4>
                            <p class="card-sub mt-3">
                                <?php echo e(Str($blog->description)->limit(30 , '...')); ?>

                            </p>
                            <ul class="listing-action d-flex justify-content-around align-items-center border-top border-top-color mt-4 pt-4">
                                <li class="pill"><i class="la la-eye mr-1"></i><?php echo e($blog->views); ?></li>
                                <li class="pill"><i class="la la-comment mr-1"></i><?php echo e($blog->comments->count()); ?></li>
                            </ul>
                        </div><!-- end card-content -->
                    </div><!-- end card-item -->
                </div><!-- end col-lg-4 -->
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="mx-auto">
                    <h3 class="pb-24 text-color-9 mb-5"><?php echo e(__('No posts have been created so far')); ?></h3>
                </div>
            <?php endif; ?>
        </div><!-- end row -->
        <div class="more-btn-box pt-3 text-center">
            <a href="<?php echo e(route('blog')); ?>" class="theme-btn gradient-btn"><i class="la la-list-alt mr-2"></i><?php echo e(__('Browse All Posts')); ?></a>
        </div>
    </div><!-- end container -->
</section><!-- end blog-area -->
<!-- ================================
       START BLOG AREA
================================= -->
<?php /**PATH D:\personal\catnearme\resources\views/livewire/home/sections/blog.blade.php ENDPATH**/ ?>