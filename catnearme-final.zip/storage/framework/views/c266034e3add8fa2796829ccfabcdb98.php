<header class="<?php echo e(request()->routeIs('home') ? 'header-area bg-dark position-relative top-auto' : 'header-area'); ?>" wire:ignore.self>
    <div class="header-top-bar bg-dark-opacity py-2 padding-right-30px padding-left-30px">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-6 d-flex align-items-center header-top-info font-size-14 font-weight-medium">
                    <p class="login-and-signup-wrap">
                        <?php if(auth()->guard()->check()): ?>
                            <a href="<?php echo e(route('dashboard')); ?>">
                                <span class="mr-1 la la-sign-in"></span><?php echo e(__('My dashboard')); ?>

                            </a>
                        <?php elseif(auth()->guard()->guest()): ?>
                            <a href="#" data-toggle="modal" data-target="#loginModal">
                                <span class="mr-1 la la-sign-in"></span><?php echo e(__('Login')); ?>

                            </a>
                            <span class="or-text px-2"><?php echo e(__('or')); ?></span>
                            <a href="#" data-toggle="modal" data-target="#signUpModal">
                                <span class="mr-1 la la-user-plus"></span><?php echo e(__('Sign Up')); ?>

                            </a>
                        <?php endif; ?>
                    </p>
                </div><!-- end col-lg-6 -->
                <div class="col-lg-6 d-flex align-items-center justify-content-end header-top-info">
                    <ul class="list-items list-items-style d-flex">
                        <li><a href="tel:<?php echo e($setting->phone); ?> "><i class="la la-phone mr-1"></i><?php echo e($setting->phone); ?> SMS Only</a></li>
                    </ul>
                    <ul class="social-profile social-profile-colored pl-3">
                        <li><a href="<?php echo e(config('cat.social.facebook')); ?>" class="facebook-bg"><i class="lab la-facebook-f"></i></a></li>
                        <li><a href="<?php echo e(config('cat.social.youtube')); ?>" class="twitter-bg"><i class="lab la-youtube"></i></a></li>
                        <li><a href="<?php echo e(config('cat.social.instagram')); ?>" class="instagram-bg"><i class="lab la-instagram"></i></a></li>
                    </ul>
                </div>
            </div><!-- end row -->
        </div><!-- end container-fluid -->
    </div><!-- end header-top-bar -->
    <div class="header-menu-wrapper padding-right-30px padding-left-30px">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <div class="menu-full-width">
                        <div class="logo">
                            <a href="<?php echo e(route('home')); ?>">
                                <img src="<?php echo e(Vite::asset('resources/images/logo.png')); ?>" alt="logo" width="135" height="38">
                            </a>
                            <div class="d-flex align-items-center">
                                <a href="<?php echo e(route('pets.add')); ?>" class="btn-gray add-listing-btn-show font-size-24 mr-2 flex-shrink-0" data-toggle="tooltip" data-placement="left" title="Add Pet Breed">
                                    <i class="la la-plus"></i>
                                </a>
                                <div class="menu-toggle">
                                    <span class="menu__bar"></span>
                                    <span class="menu__bar"></span>
                                    <span class="menu__bar"></span>
                                </div><!-- end menu-toggle -->
                            </div>
                        </div><!-- end logo -->
                        <div class="quick-search-form d-flex align-items-center">
                            <form action="#" class="w-100">
                                <div class="header-search position-relative">
                                    <i class="la la-arrow-right form-icon"></i>
                                    <input type="search" placeholder="<?php echo e(__('Choose the desired breed')); ?>">
                                    <div class="instant-results">
                                        <ul class="instant-results-list overflow-auto height-500">
                                            <?php $__currentLoopData = $breeds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $breed): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><a href="<?php echo e(route('listings.withbreed' ,$breed->slug)); ?>" class="d-flex align-items-center"><?php echo e($breed->title); ?></a></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div>
                                </div>
                            </form>
                        </div><!-- end quick-search-form -->
                        <div class="main-menu-content ml-auto">
                            <?php echo $__env->make('__shared.home.header.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div><!-- end main-menu-content -->
                        <div class="nav-right-content">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('breeder')): ?>
                                <a href="<?php echo e(route('pets.add')); ?>" class="theme-btn gradient-btn shadow-none add-listing-btn-hide">
                                    <i class="la la-layer-group mr-2"></i><?php echo e(__('Add Pet')); ?>

                                </a>
                            <?php elseif (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('client')): ?>
                                <a href="<?php echo e(route('dashboard')); ?>" class="theme-btn gradient-btn shadow-none add-listing-btn-hide">
                                    <i class="la la-layer-group mr-2"></i><?php echo e(__('My dashboard')); ?>

                                </a>
                            <?php endif; ?>
                        </div><!-- end nav-right-content -->
                    </div><!-- end menu-full-width -->
                </div><!-- end col-lg-12 -->
            </div><!-- end row -->
        </div><!-- end container-fluid -->
    </div><!-- end header-menu-wrapper -->
</header>
<?php /**PATH D:\personal\catnearme\resources\views/livewire/home/headers/black.blade.php ENDPATH**/ ?>