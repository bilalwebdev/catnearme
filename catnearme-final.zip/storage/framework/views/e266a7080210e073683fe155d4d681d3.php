<div>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('home.headers.white', [])->html();
} elseif ($_instance->childHasBeenRendered('l3967744337-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l3967744337-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l3967744337-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l3967744337-0');
} else {
    $response = \Livewire\Livewire::mount('home.headers.white', []);
    $html = $response->html();
    $_instance->logRenderedChild('l3967744337-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    <!-- ================================
        START FULL SCREEN SLIDER
    ================================= -->
    <section class="full-screen-slider-area" >
        <div class="full-screen-slider owl-trigger-action owl-trigger-action-2" wire:ignore>
            <?php $__currentLoopData = $pet->getMedia('photos'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e($gallery->getUrl('gallery')); ?>" class="fs-slider-item d-block" data-fancybox="gallery" data-caption="Showing image - 01">
                    <img src="<?php echo e($gallery->getUrl('gallery')); ?>" alt="single listing image">
                </a><!-- end fs-slider-item -->
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section><!-- end full-screen-slider-area -->
    <!-- ================================
        END FULL SCREEN SLIDER
    ================================= -->

    <section class="breadcrumb-area bg-gradient-gray py-5">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="breadcrumb-content breadcrumb-content-2 d-flex flex-wrap align-items-end justify-content-between">
                        <div class="section-heading">

                            <div class="user-bio margin-bottom-30px">
                                <a href="<?php echo e(route('user.breeder.profile', $pet->user)); ?>" class="d-flex align-items-center">
                                    <div class="user-thumb user-thumb-md mr-3">
                                        <img src="<?php echo e($pet->user->getFirstMediaUrl('avatar' , 'thumb')); ?>" alt="<?php echo e($pet->user->username); ?>">
                                    </div>
                                    <div class="user-inner-bio">
                                        <div class="d-flex justify-content-between">
                                            <h4 class="author__title mr-1"><?php echo e($pet->user->username); ?></h4>
                                            <?php if($pet->user->is_verify): ?>
                                                <div class="shield-user">
                                                    <img src="<?php echo e(Vite::asset('resources/images/home/shield-transparent.png')); ?>" width="100">
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                        <p class="author__meta"><?php echo e($pet->user->country->name); ?></p>
                                    </div>
                                </a>
                            </div>


                            <div class="d-flex align-items-center pt-1">
                                <h2 class="sec__title mb-0"><?php echo e($pet->title); ?></h2>
                            </div>
                            <div class="d-flex flex-wrap align-items-center">
                                <div class="star-rating-wrap d-flex align-items-center">
                                    <div class="star-rating text-color-5 font-size-18">
                                        <?php for($rating = 0; $rating < $pet->user->averageRating(); $rating++): ?>
                                            <span><i class="la la-star"></i></span>
                                        <?php endfor; ?>
                                    </div>
                                    <p class="font-size-14 pl-2 font-weight-medium"><?php echo e($pet->user->reviews->count()); ?> <?php echo e(__('reviews')); ?></p>
                                </div>
                            </div>
                            <div class="badge badge-warning font-size-22 mt-3"><?php echo e($pet->user->averageRating(1) ?? 0.0); ?></div>
                        </div>
                        <div class="btn-box d-flex align-items-center">
                            <span class="btn-gray mr-2"><i class="la la-eye mr-1"></i><?php echo e(__('Views')); ?> - <?php echo e($pet->views); ?></span>
                        </div>
                    </div><!-- end breadcrumb-content -->
                </div><!-- end col-lg-12 -->
            </div><!-- end row -->
        </div><!-- end container -->
    </section>
    <section class="listing-detail-area padding-top-60px padding-bottom-100px">
        <div class="container">
            <div class="row">
                <div class="col-lg-8">
                    <div class="listing-detail-wrap">
                        <div class="block-card mb-4">
                            <div class="block-card-header">
                                <h2 class="widget-title"><?php echo e(__('Description')); ?></h2>
                                <div class="stroke-shape"></div>
                            </div><!-- end block-card-header -->
                            <div class="block-card-body">
                                <p class="pb-3 font-weight-medium line-height-30">
                                    <?php echo e(str($pet->description)->limit(30 ,'...')); ?>

                                </p>
                                <div class="collapse collapse-content" id="showMoreOptionCollapse">
                                    <p class="font-weight-medium line-height-30 pb-3">
                                        <?php echo $pet->description; ?>

                                    </p>
                                </div>
                                <a class="collapse-btn" data-toggle="collapse" href="#showMoreOptionCollapse" role="button" aria-expanded="false" aria-controls="showMoreOptionCollapse">
                                    <span class="collapse-btn-hide"><?php echo e(__('Read More')); ?> <i class="la la-plus ml-1"></i></span>
                                    <span class="collapse-btn-show"><?php echo e(__('Read Less')); ?> <i class="la la-minus ml-1"></i></span>
                                </a>
                            </div><!-- end block-card-body -->
                        </div><!-- end block-card -->
                        <div class="block-card mb-4">
                            <div class="block-card-header">
                                <h2 class="widget-title"><?php echo e(__('General Information')); ?></h2>
                                <div class="stroke-shape"></div>
                            </div><!-- end block-card-header -->
                            <div class="block-card-body">
                                <div class="info-list-box">
                                    <ul class="row info-list">
                                        <li class="col-lg-6"><span aria-hidden="true"><i class="la la-circle-o"></i></span><?php echo e(__('Breed')); ?> - <?php echo e($pet->breed->title); ?></li>
                                        <li class="col-lg-6"><span aria-hidden="true"><i class="la la-circle-o"></i></span><?php echo e(__('Age')); ?> - <?php echo e($pet->age); ?></li>
                                        <li class="col-lg-6"><span aria-hidden="true"><i class="la la-circle-o"></i></span><?php echo e(__('Gender')); ?> - <?php echo e($pet->gender); ?></li>
                                        <li class="col-lg-6"><span aria-hidden="true"><i class="la la-circle-o"></i></span><?php echo e(__('Color')); ?> - <?php echo e($pet->color); ?></li>
                                    </ul>
                                </div>
                            </div><!-- end block-card-body -->
                        </div>


                        <div class="block-card mb-4">
                            <div class="block-card-header">
                                <h2 class="widget-title"><?php echo e(__('Vactinations')); ?></h2>
                                <div class="stroke-shape"></div>
                            </div><!-- end block-card-header -->
                            <div class="block-card-body">
                                <ul class="list-items row">
                                    <div class="col-lg-6">
                                        <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.home.ui.question-checkbox','data' => ['disabled' => true,'title' => 'Feline Herpesvirus (FHV)','wire:model' => 'vactinations.fnv','popup' => 'Protects against the feline herpesvirus, a common respiratory infection in cats.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('home.ui.question-checkbox'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['disabled' => true,'title' => 'Feline Herpesvirus (FHV)','wire:model' => 'vactinations.fnv','popup' => 'Protects against the feline herpesvirus, a common respiratory infection in cats.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                                    </div><!-- end col-lg-4 -->

                                    <div class="col-lg-6">
                                        <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.home.ui.question-checkbox','data' => ['disabled' => true,'title' => 'Feline Calicivirus (FCV)','wire:model' => 'vactinations.fcv','popup' => 'Guards against feline calicivirus, another viral respiratory infection in cats.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('home.ui.question-checkbox'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['disabled' => true,'title' => 'Feline Calicivirus (FCV)','wire:model' => 'vactinations.fcv','popup' => 'Guards against feline calicivirus, another viral respiratory infection in cats.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                                    </div><!-- end col-lg-4 -->
                                    <div class="col-lg-6">
                                        <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.home.ui.question-checkbox','data' => ['disabled' => true,'title' => 'Feline Panleukopenia (FPV)','wire:model' => 'vactinations.fpv','popup' => 'Also known as the feline distemper vaccine, it protects against a highly contagious and potentially deadly viral infection.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('home.ui.question-checkbox'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['disabled' => true,'title' => 'Feline Panleukopenia (FPV)','wire:model' => 'vactinations.fpv','popup' => 'Also known as the feline distemper vaccine, it protects against a highly contagious and potentially deadly viral infection.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                                    </div><!-- end col-lg-6 -->

                                    <div class="col-lg-6">
                                        <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.home.ui.question-checkbox','data' => ['disabled' => true,'title' => 'Rabies','wire:model' => 'vactinations.rabies','popup' => 'Required by law in many regions, the rabies vaccine protects against the rabies virus, which can affect cats and humans.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('home.ui.question-checkbox'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['disabled' => true,'title' => 'Rabies','wire:model' => 'vactinations.rabies','popup' => 'Required by law in many regions, the rabies vaccine protects against the rabies virus, which can affect cats and humans.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                                    </div><!-- end col-lg-6 -->

                                    <div class="col-lg-6">
                                        <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.home.ui.question-checkbox','data' => ['disabled' => true,'title' => 'Feline Leukemia Virus (FeLV)','wire:model' => 'vactinations.felv','popup' => 'Recommended for cats at risk of exposure to the feline leukemia virus, which can cause various health issues, including immune suppression and cancer.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('home.ui.question-checkbox'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['disabled' => true,'title' => 'Feline Leukemia Virus (FeLV)','wire:model' => 'vactinations.felv','popup' => 'Recommended for cats at risk of exposure to the feline leukemia virus, which can cause various health issues, including immune suppression and cancer.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                                    </div><!-- end col-lg-6 -->

                                    <div class="col-lg-6">
                                        <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.home.ui.question-checkbox','data' => ['disabled' => true,'title' => 'Chlamydia','wire:model' => 'vactinations.chlamydia','popup' => 'Offers protection against chlamydia, a bacterial infection that can lead to conjunctivitis and respiratory problems in cats.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('home.ui.question-checkbox'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['disabled' => true,'title' => 'Chlamydia','wire:model' => 'vactinations.chlamydia','popup' => 'Offers protection against chlamydia, a bacterial infection that can lead to conjunctivitis and respiratory problems in cats.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                                    </div><!-- end col-lg-6 -->
                                </ul>
                            </div><!-- end block-card-body -->
                        </div><!-- end block-card -->
                        <div class="block-card mb-4">
                            <div class="block-card-header">
                                <h2 class="widget-title">Certification and Documentation</h2>
                                <div class="stroke-shape"></div>
                            </div><!-- end block-card-header -->
                            <div class="block-card-body">
                                <div class="form-box row">

                                    <div class="col-lg-4">
                                        <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.home.ui.question-checkbox','data' => ['disabled' => true,'title' => 'The International Cat Association (TICA)','wire:model' => 'certifications.tica','popup' => ' TICA is one of the largest and well-known cat registries worldwide. It recognizes and registers a wide range of cat breeds, holds cat shows, and promotes responsible cat breeding.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('home.ui.question-checkbox'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['disabled' => true,'title' => 'The International Cat Association (TICA)','wire:model' => 'certifications.tica','popup' => ' TICA is one of the largest and well-known cat registries worldwide. It recognizes and registers a wide range of cat breeds, holds cat shows, and promotes responsible cat breeding.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                                    </div><!-- end col-lg-4 -->

                                    <div class="col-lg-4">
                                        <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.home.ui.question-checkbox','data' => ['disabled' => true,'title' => 'Cat Fanciers\' Association (CFA)','wire:model' => 'certifications.cfa','popup' => 'CFA is another major cat registry and breeder association. It is one of the oldest and most prestigious cat organizations in North America, recognizing and promoting purebred cats through cat shows, breed standards, and educational programs.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('home.ui.question-checkbox'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['disabled' => true,'title' => 'Cat Fanciers\' Association (CFA)','wire:model' => 'certifications.cfa','popup' => 'CFA is another major cat registry and breeder association. It is one of the oldest and most prestigious cat organizations in North America, recognizing and promoting purebred cats through cat shows, breed standards, and educational programs.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                                    </div><!-- end col-lg-4 -->


                                    <div class="col-lg-4">
                                        <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.home.ui.question-checkbox','data' => ['disabled' => true,'title' => 'American Cat Fanciers Association (ACFA)','wire:model' => 'certifications.acfa','popup' => 'ACFA is an organization based in the United States that focuses on cat shows, breed recognition, and promoting responsible cat breeding practices. It recognizes and registers various cat breeds.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('home.ui.question-checkbox'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['disabled' => true,'title' => 'American Cat Fanciers Association (ACFA)','wire:model' => 'certifications.acfa','popup' => 'ACFA is an organization based in the United States that focuses on cat shows, breed recognition, and promoting responsible cat breeding practices. It recognizes and registers various cat breeds.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                                    </div><!-- end col-lg-6 -->

                                    <div class="col-lg-4">
                                        <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.home.ui.question-checkbox','data' => ['disabled' => true,'title' => 'The Governing Council of the Cat Fancy (GCCF)','wire:model' => 'certifications.gccf','popup' => 'GCCF is the primary cat registry and breeder association in the United Kingdom. It oversees the registration, breed standards, and shows for pedigree cats.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('home.ui.question-checkbox'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['disabled' => true,'title' => 'The Governing Council of the Cat Fancy (GCCF)','wire:model' => 'certifications.gccf','popup' => 'GCCF is the primary cat registry and breeder association in the United Kingdom. It oversees the registration, breed standards, and shows for pedigree cats.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                                    </div><!-- end col-lg-6 -->


                                    <div class="col-lg-4">
                                        <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.home.ui.question-checkbox','data' => ['disabled' => true,'title' => 'Cat Control Council of New South Wales (CCC of NSW)','wire:model' => 'certifications.ccc_nsw','popup' => 'CCC of NSW is an Australian cat registry and breeder association that promotes responsible breeding, cat welfare, and organizes cat shows in the state of New South Wales.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('home.ui.question-checkbox'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['disabled' => true,'title' => 'Cat Control Council of New South Wales (CCC of NSW)','wire:model' => 'certifications.ccc_nsw','popup' => 'CCC of NSW is an Australian cat registry and breeder association that promotes responsible breeding, cat welfare, and organizes cat shows in the state of New South Wales.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                                    </div><!-- end col-lg-6 -->

                                    <div class="col-lg-4">
                                        <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.home.ui.question-checkbox','data' => ['disabled' => true,'title' => 'The World Cat Federation (WCF)','wire:model' => 'certifications.wcf','popup' => 'Founded in 1988, the WCF is headquartered in Germany and has member organizations and clubs in multiple countries around the world.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('home.ui.question-checkbox'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['disabled' => true,'title' => 'The World Cat Federation (WCF)','wire:model' => 'certifications.wcf','popup' => 'Founded in 1988, the WCF is headquartered in Germany and has member organizations and clubs in multiple countries around the world.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                                    </div><!-- end col-lg-6 -->

                                </div>
                            </div><!-- end block-card-body -->
                        </div><!-- end block-card -->
                        <div class="block-card mb-4">
                            <div class="block-card-header">
                                <h2 class="widget-title"><?php echo e(__('Location')); ?> / <?php echo e(__('Contact')); ?></h2>
                                <div class="stroke-shape"></div>
                            </div><!-- end block-card-header -->
                            <div class="block-card-body">
                                <div class="map-container height-400">
                                    <div class="map-container height-400">
                                        <div id="map"></div>
                                    </div>
                                </div>
                                <ul class="list-items list--items list-items-style-2 py-4">
                                    <li><span class="text-color"><i class="la la-map mr-2 text-color-2 font-size-18"></i><?php echo e(__('Address')); ?>:</span> <?php echo e($pet->user->address ?? 'No address'); ?></li>
                                    <li><span class="text-color"><i class="la la-phone mr-2 text-color-2 font-size-18"></i><?php echo e(__('Phone')); ?>:</span><a href="tel:<?php echo e($pet->user->phone_number); ?>"><?php echo e($pet->user->phone_number ?? 'No phone number'); ?></a></li>
                                    <li><span class="text-color"><i class="la la-envelope mr-2 text-color-2 font-size-18"></i><?php echo e(__('Email')); ?>:</span><a href="mailto:<?php echo e($pet->user->email); ?>"><?php echo e($pet->user->email); ?></a></li>
                                </ul>
                            </div><!-- end block-card-body -->
                        </div><!-- end block-card -->

                        <?php if(! $faqs->isEmpty()): ?>
                          <div class="block-card mb-4">
                            <div class="block-card-header">
                                <h2 class="widget-title"><?php echo e(__('Questions')); ?> &amp; <?php echo e(__('Answers')); ?></h2>
                                <div class="stroke-shape"></div>
                            </div><!-- end block-card-header -->
                            <div class="block-card-body">
                                <div class="accordion-item" id="accordion">
                                    <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="card">
                                            <div class="card-header" id="<?php echo e($faq->id); ?>">
                                                <h5>
                                                    <button class="btn btn-link d-flex align-items-center justify-content-between" data-toggle="collapse" data-target="#collapse-<?php echo e($faq->id); ?>" aria-expanded="true" aria-controls="collapse-<?php echo e($faq->id); ?>">
                                                        <?php echo e($faq->name); ?>

                                                        <i class="la la-minus"></i>
                                                        <i class="la la-plus"></i>
                                                    </button>
                                                </h5>
                                            </div>
                                            <div id="collapse-<?php echo e($faq->id); ?>" class="collapse" aria-labelledby="heading-<?php echo e($faq->id); ?>" data-parent="#accordion">
                                                <div class="card-body">
                                                    <p><?php echo e($faq->text); ?></p>
                                                </div>
                                            </div>
                                        </div><!-- end card -->
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div><!-- end block-card-body -->
                        </div><!-- end block-card -->
                        <?php endif; ?>
                    </div><!-- end listing-detail-wrap -->


                    <div class="block-card mb-4">
                        <div class="block-card-header">
                            <h2 class="widget-title"><?php echo e(__('Calendar')); ?></h2>
                            <div class="stroke-shape"></div>
                        </div><!-- end block-card-header -->
                        <div class="block-card-body">

                            <?php if(is_null($pet->user->plan) || $pet?->user?->plan?->name == '3_listing'): ?>
                                <div style="backdrop-filter: blur(1px);background-color: #ffffff00;filter: blur(8px);">
                                    <div id='calendar'></div>
                                </div>
                            <?php else: ?>
                                <div id='calendar'></div>
                            <?php endif; ?>
                        </div><!-- end block-card-body -->
                    </div><!-- end block-card -->

                </div><!-- end col-lg-8 -->
                <div class="col-lg-4">
                    <div class="sidebar mb-0">
                        <div class="sidebar-widget">
                            <h3 class="widget-title"><?php echo e(__('Pricing')); ?></h3>
                            <div class="stroke-shape mb-4"></div>
                            <div>
                                <h1 class="mb-2 text-color-1">Price: $<?php echo e($pet->price); ?></h1>
                                <h5 class="text-color-1"><?php echo e(__('Price breeding')); ?>: $<?php echo e($pet->price_breeding); ?></h5>

                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('notAuthor', $pet)): ?>
                                    <div class="btn-box pt-3 w-">
                                        <a href="javascript:void(0)" wire:click="sendMessage" class="btn-gray mr-1"><i class="la la-comment mr-1"></i><?php echo e(__('Write a message')); ?></a>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div><!-- end sidebar-widget -->

                        <div class="sidebar-widget">
                            <h3 class="widget-title"><?php echo e(__('Shipping')); ?></h3>
                            <div class="stroke-shape mb-4"></div>
                            <span class="text-color-4 mr-2"><?php echo e(__('Delivery')); ?>:</span>

                            <?php if($pet?->shipping?->shipping_fee): ?>
                                <span><?php echo e($pet?->shipping?->shipping_price); ?></span>$
                            <?php else: ?>
                                <span><?php echo e(__('Shipping destination')); ?></span>
                            <?php endif; ?>
                        </div><!-- end sidebar-widget -->
                        <div class="sidebar-widget">
                            <div class="section-tab section-tab-layout-2 mb-4">
                                <ul class="nav nav-tabs" id="myTab" role="tablist">
                                    <li class="nav-item">
                                        <a class="nav-link active" id="popular-tab" data-toggle="tab" href="#parents" role="tab" aria-controls="popular" aria-selected="true">
                                            <?php echo e(__('Parents')); ?>

                                        </a>
                                    </li>
                                </ul>
                            </div>
                            <div class="tab-content" id="myTabContent">
                                <div class="tab-pane fade show active" id="parents" role="tabpanel" aria-labelledby="popular-tab">
                                    <?php $__currentLoopData = $parents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="mini-list-card">
                                            <div class="mini-list-img">
                                                <a href="<?php echo e(route('family.show', $parent->family)); ?>" class="d-block">
                                                    <img src="<?php echo e($parent->family->getFirstMediaUrl('photo' , 'thumb')); ?>" alt="parent as pet - <?php echo e($parent->family->name); ?>">
                                                </a>
                                            </div><!-- end mini-list-img -->
                                            <div class="mini-list-body">
                                                <h1 class="mini-list-title font-size-20 mb-3">
                                                    <a href="<?php echo e(route('family.show', $parent->family)); ?>"><?php echo e($parent->family->name); ?></a>
                                                </h1>
                                                <span>Breed: <?php echo e($parent->family->breed->title); ?></span>
                                                <span class="badge badge-dark"><?php echo e($parent->family->who); ?></span>
                                            </div><!-- end mini-list-body -->
                                        </div><!-- end mini-list-card -->
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div><!-- end sidebar-widget -->
                    </div><!-- end sidebar -->
                </div><!-- end col-lg-4 -->
            </div><!-- end row -->
        </div><!-- end container -->
    </section>

    <?php $__env->startPush('scripts'); ?>

        <script src='https://cdn.jsdelivr.net/npm/fullcalendar@6.1.8/index.global.min.js'></script>

        <script>

            document.addEventListener('DOMContentLoaded', function () {

                var calendarEl = document.getElementById('calendar');
                var calendar = new FullCalendar.Calendar(calendarEl, {

                    aspectRatio: 3,
                    eventColor: '#378006',
                    displayEventTime: false,

                    events: <?php echo e(Js::from($events)); ?>,

                    initialView: 'dayGridMonth',
                });

                //  calendar.addEvent({ title: 'new event', start: '2023-17-08' });

                calendar.render();
            });

        </script>

        <script>

            var cities = L.layerGroup();

            var marker = L.marker([<?php echo e($pet->user->lat); ?>, <?php echo e($pet->user->lng); ?>]).addTo(cities);

            var mbAttr = 'Map data &copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors, Imagery © <a href="https://www.mapbox.com/">Mapbox</a>';
            var mbUrl = 'https://api.mapbox.com/styles/v1/{id}/tiles/{z}/{x}/{y}?access_token=pk.eyJ1IjoibWFwYm94IiwiYSI6ImNpejY4NXVycTA2emYycXBndHRqcmZ3N3gifQ.rJcFIG214AriISLbB6B5aw';

            var streets = L.tileLayer(mbUrl, {id: 'mapbox/streets-v11', tileSize: 512, zoomOffset: -1, attribution: mbAttr});

            var osm = L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
                minZoom: 3
            });


            var map = L.map('map', {
                center: ["<?php echo e($pet->user->lat); ?>", "<?php echo e($pet->user->lng); ?>"],
                zoom: 3,
                layers: [osm, cities]
            });

            map.attributionControl.setPrefix(false)

            var baseLayers = {
                'OpenStreetMap': osm,
                'Streets': streets
            };

            var overlays = {
                'Cities': cities
            };

        </script>
    <?php $__env->stopPush(); ?>

</div>
<?php /**PATH D:\personal\catnearme\resources\views/livewire/home/pages/listings/show.blade.php ENDPATH**/ ?>