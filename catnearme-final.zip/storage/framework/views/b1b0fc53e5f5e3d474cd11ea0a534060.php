<div>

    <?php $__env->startPush('styles'); ?>
        <style>
            #map { position: inherit; top:0; bottom:0; right:0; left:0; }
        </style>
    <?php $__env->stopPush(); ?>
    <div class="container-fluid dashboard-inner-body-container">
        <div class="breadcrumb-content d-sm-flex align-items-center justify-content-between mb-4">
            <div class="section-heading">
                <h2 class="sec__title font-size-24 mb-0"><?php echo e(__('My Profile')); ?></h2>
            </div>
            <?php echo e(Breadcrumbs::render('my-profile')); ?>

        </div><!-- end breadcrumb-content -->
        <div class="row">
            <div class="col-lg-9">
                <div class="block-card dashboard-card mb-4">
                    <div class="block-card-header">
                        <h2 class="widget-title pb-0"><?php echo e(__('Profile Details')); ?></h2>
                    </div>

                    <div class="block-card-body">
                        <div class="edit-profile-photo d-flex align-items-center flex-column">
                            <img src="<?php echo e(auth()->user()->getFirstMediaUrl('avatar' , 'thumb')); ?>" alt="" class="profile-img">

                            <div class="file-upload-wrap file-upload-wrap-2 mt-4">
                                <div class="MultiFile-wrap" id="MultiFile1">
                                    <input type="file" wire:model="avatar" name="files[]" class="multi file-upload-input with-preview MultiFile-applied"  maxlength="1" id="MultiFile1" value=""><div class="MultiFile-list" id="MultiFile1_list"></div>
                                </div>
                                <span class="file-upload-text"><i class="la la-photo mr-2"></i>Upload Photo</span>
                                <p>Maximum file size: 10 MB.</p>
                            </div>
                        </div><!-- end edit-profile-photo -->
                        <div class="form-box row pt-4">


                            <div class="col-lg-12 mb-3">
                                <div class="mb-4">
                                    <h3 class="mb-2">Click on the map to update your address.</h3>
                                    <p>In order to update the address, you need to click on the magnifying glass and enter the address, after entering the address, select the object and click on it, the address will be updated in the field, then don't forget to click Update to apply the information</p>
                                </div>
                                <div id="map" style="height: 300px;" wire:ignore></div>
                            </div>

                            <div class="col-lg-12">
                                <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.home.ui.textarea','data' => ['title' => 'About Me','icon' => 'la la-user','placeholder' => 'Enter about me','wire:model.defer' => 'user.about_me','class' => 'mb-5']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('home.ui.textarea'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'About Me','icon' => 'la la-user','placeholder' => 'Enter about me','wire:model.defer' => 'user.about_me','class' => 'mb-5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                            </div><!-- end col-lg-12 -->

                            <div class="col-lg-3">
                                <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.home.ui.input-box','data' => ['title' => 'Your Name','icon' => 'la la-user','placeholder' => 'Enter your name','wire:model.defer' => 'user.first_name']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('home.ui.input-box'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Your Name','icon' => 'la la-user','placeholder' => 'Enter your name','wire:model.defer' => 'user.first_name']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                            </div><!-- end col-lg-12 -->

                            <div class="col-lg-3">
                                <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.home.ui.input-box','data' => ['title' => 'Your Name','icon' => 'la la-user','placeholder' => 'Enter your name','wire:model.defer' => 'user.last_name']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('home.ui.input-box'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Your Name','icon' => 'la la-user','placeholder' => 'Enter your name','wire:model.defer' => 'user.last_name']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                            </div><!-- end col-lg-12 -->


                            <div class="col-lg-3">
                                <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.home.ui.input-box','data' => ['title' => 'Username','icon' => 'la la-user','placeholder' => 'Enter username','wire:model.defer' => 'user.username']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('home.ui.input-box'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Username','icon' => 'la la-user','placeholder' => 'Enter username','wire:model.defer' => 'user.username']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                            </div><!-- end col-lg-12 -->

                            <div class="col-lg-3">
                                <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.home.ui.input-box','data' => ['title' => 'Your Email','icon' => 'la la-envelope-o','placeholder' => 'Enter email','wire:model.defer' => 'user.email']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('home.ui.input-box'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Your Email','icon' => 'la la-envelope-o','placeholder' => 'Enter email','wire:model.defer' => 'user.email']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                            </div><!-- end col-lg-12 -->

                            <div class="col-lg-6">
                                <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.home.ui.input-box','data' => ['title' => 'Phone Number','icon' => 'la la-phone','placeholder' => '+7(123)987654','wire:model.defer' => 'user.phone_number']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('home.ui.input-box'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Phone Number','icon' => 'la la-phone','placeholder' => '+7(123)987654','wire:model.defer' => 'user.phone_number']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                            </div><!-- end col-lg-12 -->

                            <div class="col-lg-6">
                                <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.home.ui.input-box','data' => ['title' => 'Address','icon' => 'la la-map-marker','placeholder' => '+United states, state','wire:model.defer' => 'user.address']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('home.ui.input-box'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Address','icon' => 'la la-map-marker','placeholder' => '+United states, state','wire:model.defer' => 'user.address']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                            </div><!-- end col-lg-12 -->

                            <div class="col-lg-12">
                                <div class="btn-box pt-1">
                                    <button class="theme-btn gradient-btn border-0" wire:click="save"><?php echo e(__('Save Changes')); ?><i class="la la-arrow-right ml-2"></i></button>
                                </div>
                            </div><!-- end col-lg-12 -->
                        </div>
                    </div><!-- end block-card-body -->
                </div><!-- end block-card -->
            </div><!-- end col-lg-6 -->
            <div class="col-lg-3">
                <div class="block-card dashboard-card mb-4">
                    <div class="block-card-header">
                        <h2 class="widget-title pb-0"><?php echo e(__('Change Password')); ?></h2>
                    </div>
                    <div class="block-card-body">
                        <form wire:submit.prevent="changePassword" class="form-box row">
                            <div class="col-lg-12">
                                <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.home.ui.input-box-password','data' => ['title' => 'Current Password','placeholder' => '*****','wire:model.defer' => 'password.current_password']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('home.ui.input-box-password'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Current Password','placeholder' => '*****','wire:model.defer' => 'password.current_password']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                            </div><!-- end col-lg-12 -->
                            <div class="col-lg-12">
                                <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.home.ui.input-box-password','data' => ['title' => 'New Password','placeholder' => '*****','wire:model.defer' => 'password.new_password']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('home.ui.input-box-password'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'New Password','placeholder' => '*****','wire:model.defer' => 'password.new_password']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                            </div><!-- end col-lg-12 -->
                            <div class="col-lg-12">
                                <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.home.ui.input-box-password','data' => ['title' => 'Confirm New Password','placeholder' => '*****','wire:model.defer' => 'password.password_confirmation']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('home.ui.input-box-password'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Confirm New Password','placeholder' => '*****','wire:model.defer' => 'password.password_confirmation']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                            </div><!-- end col-lg-12 -->
                            <div class="col-lg-12">
                                <div class="btn-box pt-1">
                                    <button class="theme-btn gradient-btn border-0"><?php echo e(__('Change Password')); ?><i class="la la-arrow-right ml-2"></i></button>
                                </div>
                            </div><!-- end col-lg-12 -->
                        </form>
                    </div><!-- end block-card-body -->
                </div><!-- end block-card -->
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('breeder')): ?>
                    <div class="block-card dashboard-card mb-4">
                        <div class="block-card-header d-flex justify-content-between">
                            <h2 class="widget-title pb-0"><?php echo e(__('Verification documents')); ?></h2>
                        </div>
                        <div class="block-card-body">

                            <?php if(auth()->user()?->document?->status == 'submitted'): ?>
                                <p class="mb-4 text-secondary font-size-20"><?php echo e(__('The documents were sent for inspection')); ?></p>
                            <?php elseif(auth()->user()?->document?->status == 'pending_verification'): ?>
                                <p class="mb-4 font-size-20"><?php echo e(__('Documents in the process of verification')); ?></p>
                            <?php elseif(auth()->user()?->document?->status == 'verified'): ?>
                                <p class="mb-4 text-success font-size-20"><?php echo e(__('The uploaded documents have been verified')); ?></p>
                            <?php elseif(auth()->user()?->document?->status == 'rejected'): ?>
                                <p class="mb-4 text-danger font-size-20"><?php echo e(__('Uploaded documents have not been verified')); ?></p>
                            <?php elseif(auth()->user()?->document?->status == 'document_reupload'): ?>
                                <p class="mb-4 text-danger font-size-20"><?php echo e(__('Requires re-uploading of documents')); ?></p>
                            <?php endif; ?>

                            <?php if(! auth()->user()->document || auth()->user()?->document?->status == 'document_reupload'): ?>

                                <p><?php echo e(__('Upload 2 types of documents to utilize the full capabilities of the site')); ?></p>.

                                <div class="mb-3">
                                    <div class="file-upload-wrap file-upload-wrap-2">
                                        <input type="file" name="files[]" class="multi file-upload-input with-preview w-100" wire:model.defer="documents.utility_bill">
                                        <span class="file-upload-text"><i class="la la-photo mr-2"></i><?php echo e(__('Utility Bill')); ?></span>
                                        <span class="font-size-11 mt-4">
                                            <?php if(isset($documents['utility_bill'])): ?>
                                                <b><?php echo e($documents['utility_bill']->getClientOriginalName()); ?></b>
                                            <?php endif; ?>
                                        </span>
                                    </div><!-- file-upload-wrap -->
                                </div>

                                <div  class="mb-3">
                                    <div class="file-upload-wrap file-upload-wrap-2 w-100">
                                        <input type="file" name="files[]" class="multi file-upload-input with-preview w-100" wire:model.defer="documents.cat_association">
                                        <span class="file-upload-text"><i class="la la-photo mr-2"></i><?php echo e(__('Cat association')); ?></span>
                                        <span class="font-size-11 mt-4">
                                            <?php if(isset($documents['cat_association'])): ?>
                                                <b><?php echo e($documents['cat_association']->getClientOriginalName()); ?></b>
                                            <?php endif; ?>
                                        </span>
                                    </div><!-- file-upload-wrap -->
                                </div>

                                <div class="btn-box pt-1">
                                    <button class="theme-btn gradient-btn border-0" wire:click="sendDocument"><?php echo e(__('Send Verification')); ?><i class="la la-arrow-right ml-2"></i></button>
                                </div>
                            <?php endif; ?>
                        </div><!-- end block-card-body -->
                    </div><!-- end block-card -->
                <?php endif; ?>
            </div><!-- end col-lg-6 -->
        </div><!-- end row -->
    </div><!-- end dashboard-inner-body-container -->

    <?php $__env->startPush('scripts'); ?>
        <script>

            window.addEventListener('DOMContentLoaded', () => {
                const apiKey = "A7qeQaFwKfSHQTwd0Eos";

                var map = L.map('map' , {
                    minZoom: 3
                }).setView([ <?php echo e(auth()->user()->lat); ?>, <?php echo e(auth()->user()->lng); ?> ], 4);


                L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png').addTo(map);

                map.attributionControl.setPrefix(false)

                var searchControl = L.esri.Geocoding.geosearch().addTo(map);

                var results = L.layerGroup().addTo(map);

                results.addLayer(L.marker([ <?php echo e(auth()->user()->lat); ?>, <?php echo e(auth()->user()->lng); ?> ]));

                map.on('click' , (e) => {

                    L.esri.Geocoding
                        .reverseGeocode({
                            apikey: apiKey
                        })
                        .latlng(e.latlng)
                        .run(function (error, result) {
                            if (error) {
                                return;
                            }

                            results.clearLayers();
                            results.addLayer(L.marker(result.latlng).addTo(map).bindPopup(result.address.Match_addr).openPopup());
                            window.livewire.find('<?php echo e($_instance->id); ?>').set('user.lat' , e.latlng.lat)
                            window.livewire.find('<?php echo e($_instance->id); ?>').set('user.lng' , e.latlng.lng)
                            window.livewire.find('<?php echo e($_instance->id); ?>').set('user.address' , result.address.Match_addr)
                        });
                })

                searchControl.on('results', function (data) {

                    results.clearLayers();
                    for (var i = data.results.length - 1; i >= 0; i--) {

                        results.addLayer(L.marker(data.results[i].latlng));

                        window.livewire.find('<?php echo e($_instance->id); ?>').set('user.lat' , data.results[i].latlng.lat)
                        window.livewire.find('<?php echo e($_instance->id); ?>').set('user.lng' , data.results[i].latlng.lng)
                        window.livewire.find('<?php echo e($_instance->id); ?>').set('user.address' , data.results[i].text)
                    }
                });
            })
        </script>
     <?php $__env->stopPush(); ?>

</div><!-- end dashboard-inner-body -->
<?php /**PATH D:\personal\catnearme\resources\views/livewire/dashboard/profile/profile.blade.php ENDPATH**/ ?>