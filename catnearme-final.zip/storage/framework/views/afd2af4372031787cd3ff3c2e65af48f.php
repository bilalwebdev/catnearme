<div class="col-lg-3">
    <div class="sidebar mt-0">
        <div class="sidebar-widget">
            <h3 class="widget-title"><?php echo e(__('Search')); ?></h3>
            <div class="stroke-shape mb-4"></div>
            <form action="#" class="form-box" wire:ignore>

                <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.home.ui.input-box-default','data' => ['title' => ''.e(__('Keywords')).'','placeholder' => 'Search keywords','wire:model.defer' => 'keywords']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('home.ui.input-box-default'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => ''.e(__('Keywords')).'','placeholder' => 'Search keywords','wire:model.defer' => 'keywords']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>

                <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.home.ui.chosen_select','data' => ['selectTitle' => ''.e(__('Select Of Breed')).'','options' => $breeds,'value' => $breed,'wire:model.defer' => 'breed']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('home.ui.chosen_select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['selectTitle' => ''.e(__('Select Of Breed')).'','options' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($breeds),'value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($breed),'wire:model.defer' => 'breed']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>

                <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.home.ui.chosen_select','data' => ['selectTitle' => ''.e(__('Select Of Color')).'','options' => $colors,'trackBy' => 'name','trackDisplay' => 'name','value' => $color,'wire:model.defer' => 'color']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('home.ui.chosen_select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['selectTitle' => ''.e(__('Select Of Color')).'','options' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($colors),'track_by' => 'name','track_display' => 'name','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($color),'wire:model.defer' => 'color']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>

                <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.home.ui.country','data' => ['options' => $countries,'trackDisplay' => 'name','value' => $country,'wire:model.defer' => 'country']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('home.ui.country'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['options' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($countries),'track_display' => 'name','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($country),'wire:model.defer' => 'country']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>

                <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.home.ui.input-box-default','data' => ['title' => ''.e(__('Breeder')).'','placeholder' => 'Search by breeder name','wire:model.defer' => 'breeder']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('home.ui.input-box-default'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => ''.e(__('Breeder')).'','placeholder' => 'Search by breeder name','wire:model.defer' => 'breeder']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>

            </form>

        </div><!-- end sidebar-widget -->


        <div class="sidebar-widget">
            <div class="btn-box">
                <button type="submit" class="theme-btn gradient-btn w-100 border-0" wire:click="applyFilter()">
                    <?php echo e(__('Apply Filter')); ?> <i class="la la-arrow-right ml-1"></i>
                </button>
                <button type="submit" class="btn-gray btn-gray-lg mt-3 w-100" wire:click="resetFilters">
                    <i class="la la-redo-alt mr-1"></i> <?php echo e(__('Reset Filters')); ?>

                </button>
            </div>
        </div><!-- end sidebar-widget -->
        <?php if(!$left_sidebars->isEmpty()): ?>
            <div class="sidebar-widget">
                <h3 class="widget-title"><?php echo e(__('Advertising')); ?></h3>
                <?php $__currentLoopData = $left_sidebars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lftSide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e($lftSide->url); ?>">
                        <img src="<?php echo e($lftSide->getFirstMediaUrl('photo' , 'thumb')); ?>" class="w-100">
                    </a>
                    <?php echo $lftSide->iframe; ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div><!-- end sidebar-widget -->
        <?php else: ?>
            <div class="sidebar-widget">
                <h3 class="widget-title"><?php echo e(__('Advertising')); ?></h3>
                <p class="text-color-3 mb-3"><?php echo e(__('Advertising space for affiliate advertising')); ?></p>
                <hr>
                <img src="<?php echo e(asset('images/offer.png')); ?>" class="w-100">
            </div><!-- end sidebar-widget -->
        <?php endif; ?>
    </div><!-- end sidebar -->
</div><!-- end col-lg-4 -->
<div class="col-lg-6">
    <div class="row">
        <?php $__currentLoopData = $listings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-6 responsive-column">
                <div class="card-item">
                    <div class="card-image">
                        <a href="<?php echo e(route('listings.showslug',[$listing->breed->slug,$listing->slug])); ?>" class="d-block">
                            <img src="<?php echo e($listing->getFirstMediaUrl('photo' , 'thumb')); ?>" data-src="<?php echo e($listing->getFirstMediaUrl('photo' , 'thumb')); ?>" class="card__img lazy" alt="" width="270" height="270">
                        </a>
                        <?php if($listing->user->is_verify): ?>
                            <div class="bookmark-btn" data-toggle="tooltip" data-placement="top" title="<?php echo e(__('Breeder Verified')); ?>">
                                <img src="<?php echo e(Vite::asset('resources/images/home/shield-transparent.png')); ?>" width="60">
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="card-content">
                        <a href="<?php echo e(route('user.breeder.profile', $listing->user)); ?>" class="user-thumb d-inline-block" data-toggle="tooltip" data-placement="top" title="<?php echo e($listing->user->username); ?>">
                            <img src="<?php echo e($listing->user->getFirstMediaUrl('avatar', 'thumb')); ?>" alt="<?php echo e($listing->user->username); ?>">
                        </a>
                        <h4 class="card-title pt-3">
                            <a href="<?php echo e(route('listings.showslug', [$listing->breed->slug,$listing->slug])); ?>"><?php echo e($listing->title); ?></a>
                        </h4>
                        <p class="card-sub mb-2">
                            <a href="<?php echo e(route('listings' , ['country' => $listing->user->country])); ?>">
                                <i class="la la-map-marker mr-1 text-color-2"></i>
                                <?php echo e($listing->user->country->name); ?>

                            </a>
                        </p>

                        <div>
                            <span class="badge badge-warning font-size-15 mb-2"><?php echo e($listing->user->averageRating(1) ?? 0.0); ?></span>
                            <span class="ml-1"><?php echo e(__('ratings')); ?></span>
                        </div>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('client')): ?>
                            <a href="javascript:void(0)" wire:click="addFavorite('<?php echo e($listing->id); ?>')" class="mt-3"><?php echo e(__('Add to favorites')); ?></a>
                        <?php endif; ?>
                        <hr>
                        <div>
                            <ul class="mb-3 line-height-35">
                                <li><?php echo e(__('Breed')); ?>: <span class="badge badge-info p-1"><?php echo e($listing->breed->title); ?></span>
                                </li>
                                <li><?php echo e(__('Color')); ?>: <?php echo e($listing->color); ?></li>
                                <li><?php echo e(__('Gender')); ?>: <?php echo e($listing->gender); ?></li>
                                <li><?php echo e(__('Age')); ?>: <?php echo e($listing->age); ?></li>
                            </ul>
                            <h3 class="mb-1"><?php echo e(__('Price')); ?>: $<?php echo e($listing->price); ?></h3>
                            <span><?php echo e(__('Price of breeding')); ?>: <b>$<?php echo e($listing->price_breeding); ?></b></span>
                        </div>
                    </div>
                </div><!-- end card-item -->
            </div><!-- end col-lg-6 -->
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div><!-- end row -->
    <div class="row">
        <div class="col-lg-12 pt-3 text-center">
            <?php echo e($listings->links()); ?>

        </div><!-- end col-lg-12 -->
    </div><!-- end row -->
</div><!-- end col-lg-8 -->
<div class="col-lg-3">
    <div class="sidebar mt-0">
        <?php if(!$right_sidebars->isEmpty()): ?>
            <div class="sidebar-widget">
                <h3 class="widget-title"><?php echo e(__('Advertising')); ?></h3>
                <?php $__currentLoopData = $right_sidebars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rghtSide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e($rghtSide->url); ?>">
                        <img src="<?php echo e($rghtSide->getFirstMediaUrl('photo' , 'thumb')); ?>" class="w-100">
                    </a>
                    <?php echo $rghtSide->iframe; ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div><!-- end sidebar-widget -->
        <?php else: ?>
            <div class="sidebar-widget">
                <h3 class="widget-title"><?php echo e(__('Advertising')); ?></h3>
                <p class="text-color-3 mb-3"><?php echo e(__('Advertising space for affiliate advertising')); ?></p>
                <hr>
                <img src="<?php echo e(asset('images/offer.png')); ?>" class="w-100">
            </div><!-- end sidebar-widget -->
        <?php endif; ?>

    </div><!-- end sidebar -->
</div><!-- end col-lg-4 -->
<?php /**PATH D:\personal\catnearme\resources\views/__shared/home/pages/listings/free.blade.php ENDPATH**/ ?>