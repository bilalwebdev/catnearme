<div>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('home.headers.white', [])->html();
} elseif ($_instance->childHasBeenRendered('l137583957-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l137583957-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l137583957-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l137583957-0');
} else {
    $response = \Livewire\Livewire::mount('home.headers.white', []);
    $html = $response->html();
    $_instance->logRenderedChild('l137583957-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    <!-- Main Banner Section Start -->
    <div class="home-map">
        <div class="map-container height-500 w-100">
            <div id="map" wire:ignore></div>
        </div>
    </div>
    <!-- Home Map End -->

    <!-- ================================
        START BREADCRUMB AREA
    ================================= -->
    <section class="breadcrumb-area bg-gradient-gray py-4">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <div class="breadcrumb-content d-flex flex-wrap align-items-center justify-content-between">
                        <div class="section-heading">
                            <h2 class="sec__title font-size-26 mb-0"><?php echo e($seo->heading ?? ''); ?></h2>
                        </div>
                        <?php echo e(Breadcrumbs::render('listings')); ?>

                    </div><!-- end breadcrumb-content -->
                </div><!-- end col-lg-12 -->
            </div><!-- end row -->
        </div><!-- end container -->
    </section><!-- end breadcrumb-area -->
    <!-- ================================
        END BREADCRUMB AREA
    ================================= -->

    <section class="card-area section-padding">

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('is_free')): ?>
            <div class="container" style="max-width: 1600px">
            <?php else: ?>
                <div class="container">
                <?php endif; ?>

                <div class="row">
                    <div class="col-lg-12">
                        <div
                            class="filter-bar d-flex flex-wrap justify-content-between align-items-center margin-bottom-30px">
                            <p class="result-text font-weight-medium"><?php echo e(__('Showing')); ?> <?php echo e($listings->firstItem()); ?>

                                <?php echo e(__('to')); ?> <?php echo e($listings->lastItem()); ?> <?php echo e(__('of')); ?>

                                <?php echo e($listings->total()); ?> <?php echo e(__('entries')); ?></p>
                        </div><!-- end filter-bar -->
                    </div><!-- end col-lg-12 -->

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('is_free')): ?>
                        <?php echo $__env->make('__shared.home.pages.listings.free', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php else: ?>
                        <?php echo $__env->make('__shared.home.pages.listings.subscribed', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php endif; ?>
                    </div><!-- end row -->
                </div><!-- end container -->
        </section><!-- end card-area -->
        <!-- ================================
            END CARD AREA
        ================================= -->

        <?php $__env->startPush('scripts'); ?>
            <script>
                window.addEventListener('reload', (e) => {
                    window.location.href = '/cats-and-kittens-for-sale?' + e.detail.q
                })

                var cities = L.layerGroup();

                const listings = <?php echo e(\Illuminate\Support\Js::from($listingItems)); ?>;

                listings.forEach(function(item) {
                    L.marker([item.user.lat, item.user.lng]).bindPopup(
                        `<img src="${item.photo}" style="max-width: 125px"><br><br><b>${item.title}</b><br>Color: ${item.color}<br>Age: ${item.age}<br> Price: <b>$${item.price}</b><br>Price breeding: <b>$${item.price_breeding}</b><br> <br> <a href="/listings/show/${item.id}">Go To Listing</a>`
                    ).addTo(cities);
                })

                var mbAttr =
                    'Map data &copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors, Imagery © <a href="https://www.mapbox.com/">Mapbox</a>';
                var mbUrl =
                    'https://api.mapbox.com/styles/v1/{id}/tiles/{z}/{x}/{y}?access_token=pk.eyJ1IjoibWFwYm94IiwiYSI6ImNpejY4NXVycTA2emYycXBndHRqcmZ3N3gifQ.rJcFIG214AriISLbB6B5aw';

                var streets = L.tileLayer(mbUrl, {
                    id: 'mapbox/streets-v11',
                    tileSize: 512,
                    zoomOffset: -1,
                    attribution: mbAttr
                });

                var osm = L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
                    maxZoom: 19,
                    minZoom: 3
                });

                var map = L.map('map', {
                    center: [38.9072, 77.0369],
                    zoom: 3,
                    layers: [osm, cities]
                });

                map.attributionControl.setPrefix(false)

                var baseLayers = {
                    'OpenStreetMap': osm,
                    'Streets': streets
                };

                var overlays = {
                    'Cities': cities
                };
            </script>
        <?php $__env->stopPush(); ?>
    </div>
<?php /**PATH D:\personal\catnearme\resources\views/livewire/home/pages/listings/index.blade.php ENDPATH**/ ?>