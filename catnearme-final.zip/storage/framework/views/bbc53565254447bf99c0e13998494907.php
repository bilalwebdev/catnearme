<div class="dashboard-footer bg-white">
    <div class="container-fluid">
        <div class="copy-right d-flex align-items-center justify-content-between">
            <p class="copy__desc">
                © Copyright CatNearMe <?=date('Y');?>
            </p>
            <ul class="list-items term-list text-right">
                <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
                <li><a href="<?php echo e(route('about')); ?>">About</a></li>
                <li><a href="<?php echo e(route('contacts')); ?>">Contact</a></li>
            </ul>
        </div>
    </div>
</div>
<?php /**PATH D:\personal\catnearme\resources\views/__shared/home/footer/dashboard.blade.php ENDPATH**/ ?>