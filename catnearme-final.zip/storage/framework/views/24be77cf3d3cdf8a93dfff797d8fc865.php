<!-- ================================
        START CARD AREA
    ================================= -->
<section class="card-area section-padding">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="section-heading text-center">
                    <p class="sec__desc pb-2 "><?php echo e(__('Discover Offers of our Verified Breeders')); ?></p>
                    <h2 class="sec__title mb-0"><?php echo e(__('Kittens Available Now')); ?></h2>
                </div><!-- end section-heading -->
            </div><!-- end col-lg-12 -->
        </div><!-- end row -->
        <div class="row padding-top-60px">
            <div class="col-lg-12">
                <div class="card-carousel owl-trigger-action">
                    <?php $__currentLoopData = $pets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="card-item border border-color">
                            <div class="card-image">
                                <a href="<?php echo e(route('listings.showslug', [$pet->breed->slug, $pet->slug])); ?>" class="d-block">
                                    <img src="<?php echo e($pet->getFirstMediaUrl('photo' , 'thumb')); ?>" class="card__img" alt="<?php echo e($pet->title); ?>">
                                    <span class="badge"><?php echo e($pet->created_at->isoFormat('LLL')); ?></span>
                                </a>
                            </div>
                            <div class="card-content">
                                <a href="<?php echo e(route('user.breeder.profile', $pet->user)); ?>"
                                   class="user-thumb d-inline-block" data-toggle="tooltip"
                                   data-placement="top"
                                   title="<?php echo e(__('Breeder')); ?>: <?php echo e($pet->user->username); ?>">
                                    <img src="<?php echo e($pet->user->getFirstMediaUrl('avatar' , 'thumb')); ?>"
                                         alt="<?php echo e(__('Breed')); ?>: <?php echo e($pet->user->username); ?>">
                                </a>
                                <h4 class="card-title pt-3">
                                    <div class="d-flex justify-content-between">
                                        <a href="<?php echo e(route('listings.showslug', [$pet->breed->slug, $pet->slug])); ?>"><?php echo e($pet->title); ?></a>
                                        <img style="width: 30px" class="verified-pet"
                                             src="<?php echo e(Vite::asset('resources/images/home/shield.png')); ?>"
                                             alt="<?php echo e(__('Verified')); ?>" width="1">
                                    </div>
                                </h4>
                                <p class="card-sub"><a href="<?php echo e(route('listings' , ['country' => $pet->user->country])); ?>"><i class="la la-map-marker mr-1 text-color-2"></i><?php echo e($pet->user->country->name); ?></a></p>
                                <ul class="listing-meta d-flex align-items-center">
                                    <li class="d-flex align-items-center">
                                        <span class="rate flex-shrink-1"><?php echo e($pet->user->averageRating(1) ?? 0.0); ?></span>
                                        <span class="rate-text"><?php echo e($pet->user->numberOfReviews()); ?> <?php echo e(__('Ratings')); ?></span>
                                    </li>
                                </ul>
                                <ul class="info-list padding-top-20px line-height-40">
                                    <li>
                                        <span class="la la-circle icon"></span>
                                        <a href="#"> <?php echo e(__('Breed')); ?>: <span class="badge badge-info p-2">
                                                <?php echo e($pet->breed->title); ?></span>
                                        </a>
                                    </li>
                                    <li>
                                        <span class="la la-circle icon"></span>
                                        <a href="#"> <?php echo e(__('Color')); ?>: <span><?php echo e($pet->color); ?></span></a>
                                    </li>
                                </ul>
                            </div>
                        </div><!-- end card-item -->
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div><!-- end card-carousel -->
            </div><!-- end col-lg-12 -->
        </div><!-- end row -->
    </div><!-- end container -->
</section><!-- end card-area -->
<!-- ================================
    END CARD AREA
================================= -->
<?php /**PATH D:\personal\catnearme\resources\views/livewire/home/sections/verify-breeders.blade.php ENDPATH**/ ?>