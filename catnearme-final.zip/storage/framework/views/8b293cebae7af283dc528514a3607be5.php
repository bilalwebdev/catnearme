<ul class="navbar-nav dashboard-sidebar">
    <li>
        <span id="sidebar-close">
            <i class="la la-times"></i>
       </span>
    </li>
    <li>
        <a class="sidebar-brand" href="<?php echo e(route('home')); ?>">
            <img src="<?php echo e(Vite::asset('resources/images/logo.png')); ?>" alt="logo" width="167">
        </a>
    </li>

    <li class="nav-item <?php echo e(request()->routeIs('dashboard') ? 'active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('dashboard')); ?>">
            <i class="la la-dashboard font-size-18 mr-1"></i>
            <span><?php echo e(__('Dashboard')); ?></span>
        </a>
    </li>


    <li class="sidebar-heading"><?php echo e(__('Saves')); ?></li>

    <li class="nav-item <?php echo e(request()->routeIs('dashboard.vieweds') ? 'active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('dashboard.vieweds')); ?>">
            <i class="la la-eye font-size-18 mr-1"></i>
            <span><?php echo e(__('Viewed')); ?></span>
        </a>
    </li>

    <li class="nav-item <?php echo e(request()->routeIs('dashboard.favorites') ? 'active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('dashboard.favorites')); ?>">
            <i class="la la-bookmark font-size-18 mr-1"></i>
            <span><?php echo e(__('Favorites')); ?></span>
        </a>
    </li>


    <li><hr class="sidebar-divider border-top-color"></li>
    <li class="sidebar-heading"><?php echo e(__('Messages')); ?></li>
    <li class="nav-item <?php echo e(request()->routeIs('dashboard.chat') ? 'active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('dashboard.chat')); ?>">
            <i class="la la-comment font-size-18 mr-1"></i>
            <span><?php echo e(__('Chat')); ?></span>
        </a>
    </li>



    <li><hr class="sidebar-divider border-top-color"></li>
    <li class="sidebar-heading"><?php echo e(__('Account')); ?></li>
    <li class="nav-item <?php echo e(request()->routeIs('dashboard.profile') ? 'active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('dashboard.profile')); ?>">
            <i class="la la-user font-size-18 mr-1"></i>
            <span><?php echo e(__('My Profile')); ?></span>
        </a>
    </li>

    <?php if(!$dashboard_adverts->isEmpty()): ?>
        <hr>
        <div class="p-2">
            <?php $__currentLoopData = $dashboard_adverts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $adv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e($adv->url); ?>">
                    <img src="<?php echo e($adv->getFirstMediaUrl('photo' , 'thumb')); ?>" width="300">
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>

</ul>
<?php /**PATH D:\personal\catnearme\resources\views/__shared/home/header/dashboard/client.blade.php ENDPATH**/ ?>