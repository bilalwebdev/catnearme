<div>
    <div class="container-fluid dashboard-inner-body-container">
        <div class="breadcrumb-content d-sm-flex align-items-center justify-content-between mb-4">
            <div class="section-heading">
                <h2 class="sec__title font-size-24 mb-0"><?php echo e(__('My listings')); ?></h2>
            </div>

            <div class="d-flex justify-content-end">
                <a href="<?php echo e(route('pets.add')); ?>" class="theme-btn gradient-btn border-0 mr-5">Add Listing</a>
                <?php echo e(Breadcrumbs::render('my-listing')); ?>

            </div>
        </div><!-- end breadcrumb-content -->
        <div class="row">
            <div class="col-lg-12">
                <div class="block-card dashboard-card mb-4">
                    <div class="block-card-header">
                        <h2 class="widget-title pb-0"><?php echo e(__('Pets')); ?></h2>
                    </div>
                    <div class="block-card-body">

                        <?php if($pets->isEmpty()): ?>
                            <div class="height-500 d-flex align-items-center justify-content-center flex-column">
                                <div class="text-center">
                                    <div class="mb-5">
                                        <img src="<?php echo e(asset('images/info.png')); ?>" alt="" width="120">
                                    </div>
                                    <h1 class="mb-2"><?php echo e(__('You don\'t have a listing right now')); ?></h1>
                                    <p><?php echo e(__('Start adding your listing and it will appear here')); ?></p>
                                    <div class="btn-box pt-5">
                                        <a href="<?php echo e(route('pets.add')); ?>" class="theme-btn gradient-btn border-0">Add pet listing<i class="la la-arrow-right ml-2"></i></a>
                                    </div>
                                </div>
                            </div>
                        <?php else: ?>
                            <?php $__currentLoopData = $pets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="card-item card-item-list card-item--list">
                                    <div class="card-image">
                                        <a href="<?php echo e(route('listings.show', $pet)); ?>" class="d-block">
                                            <img src="<?php echo e($pet->getFirstMediaUrl('photo' , 'thumb')); ?>"
                                                 data-src="<?php echo e($pet->getFirstMediaUrl('photo' , 'thumb')); ?>"
                                                 class="card__img lazy" alt="">
                                            <span class="badge"><?php echo e($pet->breed->title); ?></span>
                                        </a>
                                    </div>
                                    <div class="card-content">
                                        <h1 class="card-title"><a
                                                href="<?php echo e(route('listings.show', $pet)); ?>"><?php echo e($pet->title); ?></a></h1>
                                        <div class="mt-8">
                                            <div class="d-flex flex-column line-height-35">
                                                <span><?php echo e(__('Age')); ?>: <?php echo e($pet->age); ?></span>
                                                <span><?php echo e(__('Gender')); ?>: <?php echo e($pet->gender); ?></span>
                                                <span><?php echo e(__('Color')); ?>: <?php echo e($pet->color); ?></span>
                                            </div>
                                            <hr>
                                            <div class="inline-flex">
                                                <h4 class="mb-3"><?php echo e(__('Price')); ?>: $<?php echo e($pet->price); ?></h4>
                                            </div>

                                            <p class="pt-3">
                                                <span class="badge badge-dark p-2"><?php echo e($pet->created_at->isoFormat('LLL')); ?></span>
                                                <?php if($pet->status == 'active'): ?>
                                                    <span class="badge badge-success p-2"><?php echo e(__('Active')); ?></span>
                                                <?php else: ?>
                                                    <span class="badge badge-danger p-2"><?php echo e(__('Not Active')); ?></span>
                                                <?php endif; ?>
                                                <span class="badge badge-primary p-2"><?php echo e(__('Expires At')); ?>: <?php echo e($pet->expired_at->isoFormat('LLL')); ?></span>
                                            </p>
                                        </div>

                                        <div class="action-buttons position-absolute top-0 right-0 mt-3 mr-3">
                                            <a href="<?php echo e(route('dashboard.link.pet', $pet)); ?>"
                                               class="btn bg-rgb-secondary font-weight-medium mr-2"><i
                                                    class="la la-edit mr-1"></i><?php echo e(__('Add Parent')); ?></a>
                                            <a href="<?php echo e(route('pets.edit', $pet)); ?>"
                                               class="btn bg-rgb-success font-weight-medium mr-2"><i
                                                    class="la la-edit mr-1"></i><?php echo e(__('Edit')); ?></a>
                                            <a href="javascript:void(0)"
                                               onclick="confirm('Are you sure?');" class="btn bg-rgb-danger font-weight-medium"
                                               wire:click="delete('<?php echo e($pet->slug); ?>')"><i
                                                    class="la la-trash mr-1"></i><?php echo e(__('Delete')); ?></a>

                                            <?php if($pet->status == 'not_active' && $pet->renew < 3): ?>
                                                <a href="javascript:void(0)" class="btn bg-warning font-weight-medium"
                                                   wire:click="renew('<?php echo e($pet->slug); ?>')"><i
                                                        class="la la-redo-alt mr-1"></i><?php echo e(__('Renew')); ?></a>
                                            <?php endif; ?>

                                        </div>
                                    </div>
                                </div><!-- end card-item -->
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div><!-- end block-card-body -->

                    <div class="col-lg-12 pb-4">
                        <div class="text-center">
                            <?php echo e($pets->links()); ?>

                        </div>
                    </div><!-- end col-lg-12 -->

                </div><!-- end block-card -->
            </div><!-- end col-lg-12 -->
        </div><!-- end row -->
    </div><!-- end dashboard-inner-body-container -->
</div>
<?php /**PATH D:\personal\catnearme\resources\views/livewire/dashboard/breeder/pets/index.blade.php ENDPATH**/ ?>