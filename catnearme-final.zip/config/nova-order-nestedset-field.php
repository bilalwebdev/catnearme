<?php

return [
    'cache_enabled' => false,
];
