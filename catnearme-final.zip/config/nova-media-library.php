<?php

return [
    'default-croppable' => true,
    'enable-existing-media' => false,
    'hide-media-collections' => [],
];
