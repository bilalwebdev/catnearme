<?php

namespace App\Http\Livewire\Dashboard\Breeder;

use Livewire\Component;

class Verification extends Component
{
    public function render()
    {
        return view('livewire.dashboard.breeder.verification')->extends('layouts.dashboard');
    }
}
