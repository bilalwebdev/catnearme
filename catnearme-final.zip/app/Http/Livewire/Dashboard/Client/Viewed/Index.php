<?php

namespace App\Http\Livewire\Dashboard\Client\Viewed;

use Livewire\Component;

class Index extends Component
{
    public function render()
    {
        return view('livewire.dashboard.client.viewed.index');
    }
}
