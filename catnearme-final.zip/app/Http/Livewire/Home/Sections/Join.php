<?php

namespace App\Http\Livewire\Home\Sections;

use Livewire\Component;

class Join extends Component
{
    public function render()
    {
        return view('livewire.home.sections.join');
    }
}
