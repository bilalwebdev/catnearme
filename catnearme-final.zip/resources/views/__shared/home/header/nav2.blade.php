<nav class="main-menu main-menu-2">
    <ul>
        <li>
            <a href="{{ route('home') }}">{{ __('Home') }}</a>
        </li>
        <li>
            <a href="{{ route('about') }}">{{ __('About Us') }}</a>
        </li>
        <li>
            <a href="{{ route('listings') }}">{{ __('Listings') }}</a>
        </li>
        <li>
            <a href="{{ route('page.breeds') }}">{{ __('All Breeds') }}</a>
        </li>
        <li>
            <a href="{{ route('blog') }}">{{ __('Blog') }}</a>
        </li>
        <li>
            <a href="{{ route('contacts') }}">{{ __('Contact Us') }}</a>
        </li>
    </ul>
</nav>
