<x-mail::message>
    # Verified account

    Your account has been upgraded to "Verified" after your documents were examined. Priority showings and other premium services are now available to your account as per our plans.

    {{ config('app.name') }}
</x-mail::message>
