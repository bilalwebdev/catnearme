<?php echo '<?xml version="1.0" encoding="UTF-8"?>'; ?>

<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
    <sitemap>
        <loc>https://catnear.me/sitemap/posts.xml</loc>
    </sitemap>
    <sitemap>
        <loc>https://catnear.me/sitemap/categories.xml</loc>
    </sitemap>
    <sitemap>
        <loc>https://catnear.me/sitemap/breeds.xml</loc>
    </sitemap>
<sitemap>
        <loc>https://catnear.me/sitemap/countries.xml</loc>
    </sitemap>
<sitemap>
        <loc>https://catnear.me/sitemap/pets.xml</loc>
    </sitemap>
<sitemap>
        <loc>https://catnear.me/sitemap/pages.xml</loc>
    </sitemap>



</sitemapindex>