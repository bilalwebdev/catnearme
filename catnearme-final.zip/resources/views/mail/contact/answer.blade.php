<span><b>Your message</b>:</span> <br>

<p>
    {{ $clientMessage }}
</p>

<br>

<span><b>CatNearMe</b>:</span> <br>

<p>
    {!! $messageAnswer !!}
</p>

<br>
<br>

Best regards,
CatNearMe Team
